# FAIL FORWARD

**▶ Play it in your browser: https://abduschoudhury.github.io/fail-forward/**

A 2D platformer where **every death teaches you something new** — guaranteed.

The labyrinth hides its dangers: invisible spikes, bridges that secretly crumble,
lasers on unspoken rhythms, saws on unmarked routes. You *will* die. When you do:

- The hazard that killed you is **permanently revealed** (spikes appear on the map,
  crumble blocks get highlighted, lasers gain a warning glow, saw routes get drawn).
- You receive a **lesson you have never seen before** — first about what killed you,
  then about hidden movement mechanics (coyote time, jump buffering, variable jump
  height…), and eventually pure labyrinth wisdom. The lesson pool guarantees no repeats.
- A skull marks where you fell. Your deaths literally draw the map.

The death counter isn't a score. It's a curriculum.

Built with **Python + Pygame only** (plus the standard library). 5 levels.

## Controls

| Key | Action |
|---|---|
| A / D or ← / → | Move |
| SPACE / W / ↑ | Jump (tap for short hop, hold for full) |
| R | Restart attempt |
| TAB | Review every lesson you've learned |

## Run locally

```
pip install pygame
python main.py
```

Optional headless check: `python main.py --selftest`

## Post it on a website

The game is already structured for [pygbag](https://pypi.org/project/pygbag/)
(async main loop, `main.py` entry point), which compiles it to WebAssembly so it
runs in any modern browser.

1. Build and test locally:
   ```
   pip install pygbag
   python -m pygbag .
   ```
   (run from this folder). Open http://localhost:8000 to play it in your browser.

2. The finished site is in `build/web/` (an `index.html` + `.apk` bundle).

3. **GitHub Pages** (how this repo is deployed): the contents of `build/web/`
   are copied into `docs/`, and Pages serves `main` branch → `/docs`.
   To ship an update: rebuild, copy `build/web/*` into `docs/`, commit, push.

4. **Or itch.io**: zip the *contents* of `build/web/`, create an **HTML**
   project, upload the zip, check **"This file will be played in the browser"**,
   set the viewport to **960 × 540**.

> Note: browsers require a click/keypress before audio starts; pygbag shows a
> "click to start" screen that handles this automatically.
