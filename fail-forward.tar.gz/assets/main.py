"""FAIL FORWARD — a 2D platformer where every death teaches you something new.

Pygame + Python standard library only. Web-ready via pygbag (async main loop).
"""
import asyncio
import math
import random
import array
import pygame

# ---------------------------------------------------------------- constants
TILE = 30
GW, GH = 32, 18
W, H = TILE * GW, TILE * GH          # 960 x 540
FPS = 60
PW, PH = 20, 26                       # player size
GRAV, MAXFALL = 0.55, 12.0
MOVE = 4.2
JUMPV = -10.5
COYOTE, JBUF = 6, 8                   # frames of coyote time / jump buffer
CRUMBLE_DELAY = 21                    # ~0.35 s
LASER_PERIOD, LASER_ON, LASER_WARN = 2.1, 0.7, 0.35
SAW_SPEED, SAW_R = 2.2, 13

C_BG1 = (14, 15, 26)
C_BG2 = (22, 24, 40)
C_TILE = (42, 47, 69)
C_TILE_TOP = (74, 84, 124)
C_PLAYER = (90, 220, 235)
C_SPIKE = (225, 70, 90)
C_CRUMBLE = (150, 110, 70)
C_CRUMBLE_HI = (235, 170, 80)
C_LASER = (255, 80, 80)
C_SAW = (185, 190, 205)
C_EXIT = (110, 230, 140)
C_TEXT = (225, 230, 245)
C_DIM = (140, 146, 170)
C_GOLD = (245, 205, 110)

# ---------------------------------------------------------------- levels
# '#' solid   '.' empty   'S' start   'E' exit   '^' hidden spike
# 'C' crumbling block     'L' laser emitter      'M' patrolling saw
LEVELS = [
    {
        "name": "FIRST STEPS",
        "hint": "The floor is not always honest.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S.................^^.......E..",
            "#########...####################",
            "#########...####################",
            "#########...####################",
        ],
    },
    {
        "name": "CRACKS IN THE PATH",
        "hint": "Some floors hold grudges.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S............^............E...",
            "######CCCCC######CCCC###CCC#####",
            "######.....######....###...#####",
            "######.....######....###...#####",
        ],
    },
    {
        "name": "THE RHYTHM SECTION",
        "hint": "Keep perfect time.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "....########################....",
            "......L....L....L....L....L.....",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S...........................E.",
            "################################",
            "################################",
            "################################",
        ],
    },
    {
        "name": "THE PATROL",
        "hint": "The saws never rest. Use their rhythm.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            ".E..................M...........",
            "####CCCC####################....",
            "................................",
            ".............................###",
            "..S.............M...............",
            "################################",
            "################################",
            "################################",
        ],
    },
    {
        "name": "GRADUATION",
        "hint": "Everything, all at once.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..........############..........",
            "............L..L..L.............",
            "................................",
            "................................",
            "................................",
            "................................",
            ".S.....^^.............M...^^..E.",
            "##########CCCC...###############",
            "##########.......###############",
            "##########.......###############",
        ],
    },
]

# ---------------------------------------------------------------- lessons
# Every death yields a lesson the player has never seen before.
CAUSE_LESSONS = {
    "spike": [
        "Spikes hide beneath a faint glint on the floor. That shimmer you walked "
        "past was the warning. Every spike you find is revealed permanently — "
        "and now you know what the glint means.",
        "Spikes love doorsteps. The closer you are to an exit, the more suspicious "
        "the floor should feel.",
        "Revealed spikes are just terrain now. Clear them with a full jump — "
        "your jump crests at about three blocks high.",
    ],
    "crumble": [
        "Cracked blocks crumble about a third of a second after you touch them. "
        "Never stop on a bridge. From now on, crumbling blocks are highlighted in amber for you.",
        "Crumbled blocks rebuild every time you restart. A broken bridge is only "
        "broken for the rest of this attempt.",
    ],
    "laser": [
        "Lasers fire on a fixed rhythm — calm, then a burst of fire, forever. "
        "From now on, emitters glow just before firing. Walk to the beat.",
        "Neighboring lasers fire in sequence, one after another. Chase the wave — "
        "stay right behind a beam that just switched off.",
    ],
    "saw": [
        "Saws patrol a fixed route at a fixed speed — this one's path is now marked "
        "for you. They never speed up and never turn around early.",
        "You can jump clean over a saw. Let it come to you, hop it, and use the "
        "safe time behind it.",
    ],
    "fall": [
        "The pits are bottomless. A skull now marks where you fell — the labyrinth "
        "remembers your mistakes so you don't have to.",
        "There is no fall damage, and falling has a top speed. Drops never hurt — "
        "only what is at the bottom does.",
    ],
}

GENERAL_LESSONS = [
    "Coyote time: for a split second after running off an edge, you can still jump. "
    "The ledge forgives hesitation — briefly.",
    "Jump buffering: press jump just before you land and it fires the instant you "
    "touch ground. Trust the rhythm, not the reflex.",
    "Release the jump key early for a shorter hop. Small jumps are safer under "
    "low ceilings and near hazards.",
    "Your hazard hitbox is smaller than your body. A near miss that looks fatal "
    "often isn't — commit to tight gaps.",
    "Press R to restart an attempt instantly. Sometimes resetting the saws and "
    "lasers is the smartest move you have.",
    "Press TAB at any time to reread every lesson you have learned.",
    "Everything you reveal — spikes, paths, warnings — stays revealed for your "
    "whole run. Dying makes the labyrinth more honest.",
    "The exit door only needs a touch. You can brush it mid-air; nobody is "
    "grading your landing.",
    "You reach full speed instantly and stop instantly. Your movement is exact — "
    "hesitation, not control, is the enemy.",
    "Blades and beams follow perfect clocks. Watch one full cycle before you "
    "commit — the pattern never lies.",
    "Hazards reset when you do. Every attempt starts with the same saw positions "
    "and the same laser beat, so a timing that worked once works forever.",
    "Skulls mark every place you have died. A cluster of skulls is a lesson "
    "somebody refused to learn.",
    "Deaths here are lessons, not losses. The counter at the top is not a score — "
    "it is a curriculum.",
]

WISDOM = [
    "Watch first. Move second.",
    "Patience beats reflexes when the pattern is fixed.",
    "The fastest route is the one you have already died on.",
    "Fear the floor you have not tested.",
    "Mastery is a long list of survived mistakes.",
    "The labyrinth is out of secrets. Now it is only you against your own hurry.",
]

REVEAL_NOTES = {
    "spike": "+ Spikes revealed on your map, permanently.",
    "crumble": "+ All crumbling blocks are now highlighted.",
    "laser": "+ Laser emitters now glow before firing.",
    "saw": "+ This saw's patrol route is now drawn.",
    "fall": "+ A skull marks the spot.",
}


# ---------------------------------------------------------------- audio
def make_sound(freq, dur, vol=0.25, kind="square", slide=0.0):
    try:
        sr = 22050
        n = int(sr * dur)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            f = freq + slide * t
            env = min(1.0, 6.0 * (1 - i / n))
            if kind == "square":
                v = 1.0 if (t * f) % 1 < 0.5 else -1.0
            elif kind == "noise":
                v = random.uniform(-1, 1)
            else:
                v = math.sin(2 * math.pi * f * t)
            buf.append(int(v * env * vol * 32767))
        return pygame.mixer.Sound(buffer=buf.tobytes())
    except Exception:
        return None


def play(snd):
    if snd:
        try:
            snd.play()
        except Exception:
            pass


# ---------------------------------------------------------------- helpers
def wrap_text(text, font, width):
    words, lines, cur = text.split(" "), [], ""
    for w_ in words:
        trial = (cur + " " + w_).strip()
        if font.size(trial)[0] <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    return lines


def validate_levels():
    for i, lv in enumerate(LEVELS):
        m = lv["map"]
        assert len(m) == GH, f"level {i}: {len(m)} rows"
        for r, row in enumerate(m):
            assert len(row) == GW, f"level {i} row {r}: {len(row)} cols"
        flat = "".join(m)
        assert flat.count("S") == 1 and flat.count("E") == 1, f"level {i}: S/E"


# ---------------------------------------------------------------- game
class Game:
    def __init__(self, screen):
        self.screen = screen
        self.f_title = pygame.font.Font(None, 76)
        self.f_h2 = pygame.font.Font(None, 40)
        self.f_body = pygame.font.Font(None, 26)
        self.f_small = pygame.font.Font(None, 20)
        self.snd_jump = make_sound(320, 0.12, 0.14, "square", slide=400)
        self.snd_die = make_sound(180, 0.35, 0.22, "noise")
        self.snd_lesson = make_sound(520, 0.28, 0.16, "sine", slide=260)
        self.snd_clear = make_sound(440, 0.4, 0.18, "square", slide=440)
        self.snd_crumb = make_sound(120, 0.15, 0.15, "noise")
        random.seed(7)
        self.stars = [(random.randrange(W), random.randrange(H), random.random())
                      for _ in range(90)]
        self.running = True
        self.state = "menu"
        self.test_input = None
        self.reset_knowledge()

    # ---- persistent knowledge (survives deaths and levels, not full resets)
    def reset_knowledge(self):
        self.know = {
            "spikes": set(),      # (level, tx, ty) revealed
            "crumble": False,
            "laser": False,
            "saws": set(),        # (level, saw index) path revealed
            "deaths": 0,
            "lessons": [],        # [(number, text)]
            "seen": set(),
            "markers": {},        # level -> [(px, py)]
            "wisdom_n": 0,
        }
        self.particles = []
        self.li = 0

    # ---- level lifecycle
    def load_level(self, i):
        self.li = i
        m = LEVELS[i]["map"]
        self.solids = set()
        self.spikes = set()
        self.crumbles = {}
        self.lasers = []
        self.saws = []
        self.start = (60, H - 120)
        self.exit_rect = pygame.Rect(0, 0, TILE, TILE)
        for y, row in enumerate(m):
            for x, c in enumerate(row):
                if c == "#":
                    self.solids.add((x, y))
                elif c == "C":
                    self.crumbles[(x, y)] = {"t": -1, "gone": False}
                elif c == "^":
                    self.spikes.add((x, y))
                elif c == "L":
                    self.lasers.append({"tx": x, "ty": y,
                                        "off": len(self.lasers) * 0.7})
                elif c == "M":
                    self.saws.append({"tx": x, "ty": y})
                elif c == "S":
                    self.start = (x * TILE + (TILE - PW) // 2,
                                  y * TILE + TILE - PH)
                elif c == "E":
                    self.exit_rect = pygame.Rect(x * TILE + 3, (y - 1) * TILE + 6,
                                                 TILE - 6, 2 * TILE - 8)
        # saw patrol ranges: extend while the tile below is solid ground
        for s in self.saws:
            def supported(tx, ty=s["ty"]):
                below = (tx, ty + 1)
                return below in self.solids or below in self.crumbles
            lx = rx = s["tx"]
            while lx - 1 >= 0 and (lx - 1, s["ty"]) not in self.solids and supported(lx - 1):
                lx -= 1
            while rx + 1 < GW and (rx + 1, s["ty"]) not in self.solids and supported(rx + 1):
                rx += 1
            s["min_x"] = lx * TILE + SAW_R
            s["max_x"] = (rx + 1) * TILE - SAW_R
            s["home"] = s["tx"] * TILE + TILE / 2
            s["cy"] = s["ty"] * TILE + TILE / 2
            s["angle"] = 0.0
        self.reset_attempt()

    def reset_attempt(self):
        self.px, self.py = float(self.start[0]), float(self.start[1])
        self.vy = 0.0
        self.face = 1
        self.coyote = self.jbuf = 0
        self.frames = 0
        self.recent_crumble = 0
        for c in self.crumbles.values():
            c["t"], c["gone"] = -1, False
        for s in self.saws:
            s["x"], s["dir"] = s["home"], 1

    # ---- lesson machinery: guaranteed-new lesson on every death
    def new_lesson(self, cause):
        for txt in CAUSE_LESSONS.get(cause, []):
            if txt not in self.know["seen"]:
                self.know["seen"].add(txt)
                return txt
        for txt in GENERAL_LESSONS:
            if txt not in self.know["seen"]:
                self.know["seen"].add(txt)
                return txt
        self.know["wisdom_n"] += 1
        n = self.know["wisdom_n"]
        txt = f"Wisdom #{n}: {WISDOM[(n - 1) % len(WISDOM)]}"
        self.know["seen"].add(txt)
        return txt

    def reveal_spike_group(self, tx, ty):
        stack = [(tx, ty)]
        while stack:
            x, y = stack.pop()
            if (x, y) not in self.spikes or (self.li, x, y) in self.know["spikes"]:
                continue
            self.know["spikes"].add((self.li, x, y))
            stack += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

    def kill(self, cause, tile=None, saw_i=None):
        if self.state != "play":
            return
        k = self.know
        k["deaths"] += 1
        cx, cy = self.px + PW / 2, min(self.py + PH / 2, H - 10)
        k["markers"].setdefault(self.li, []).append((cx, cy))
        revealed_new = False
        if cause == "spike" and tile:
            before = len(k["spikes"])
            self.reveal_spike_group(*tile)
            revealed_new = len(k["spikes"]) > before
        elif cause == "crumble" and not k["crumble"]:
            k["crumble"] = revealed_new = True
        elif cause == "laser" and not k["laser"]:
            k["laser"] = revealed_new = True
        elif cause == "saw" and saw_i is not None:
            revealed_new = (self.li, saw_i) not in k["saws"]
            k["saws"].add((self.li, saw_i))
        elif cause == "fall":
            revealed_new = True  # the skull marker itself
        text = self.new_lesson(cause)
        k["lessons"].append((len(k["lessons"]) + 1, text))
        self.lesson_text = text
        self.lesson_note = REVEAL_NOTES[cause] if revealed_new else ""
        for _ in range(24):
            a = random.uniform(0, math.tau)
            sp = random.uniform(1, 6)
            self.particles.append([cx, cy, math.cos(a) * sp, math.sin(a) * sp - 2,
                                   random.randint(30, 60), C_SPIKE])
        play(self.snd_die)
        play(self.snd_lesson)
        self.state = "lesson"

    # ---- physics & hazards
    def is_solid(self, tx, ty):
        if (tx, ty) in self.solids:
            return True
        c = self.crumbles.get((tx, ty))
        return c is not None and not c["gone"]

    def prect(self):
        return pygame.Rect(int(self.px), int(self.py), PW, PH)

    def solid_hits(self, r):
        out = []
        for ty in range(max(0, r.top // TILE), min(GH - 1, (r.bottom - 1) // TILE) + 1):
            for tx in range(max(0, r.left // TILE), min(GW - 1, (r.right - 1) // TILE) + 1):
                if self.is_solid(tx, ty):
                    out.append(pygame.Rect(tx * TILE, ty * TILE, TILE, TILE))
        return out

    def step_play(self):
        keys = self.test_input if self.test_input is not None else pygame.key.get_pressed()
        dirx = (1 if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) else 0) - \
               (1 if (keys[pygame.K_LEFT] or keys[pygame.K_a]) else 0)
        if dirx:
            self.face = dirx
        # horizontal
        self.px = max(0.0, min(float(W - PW), self.px + dirx * MOVE))
        r = self.prect()
        for t in self.solid_hits(r):
            if dirx > 0:
                r.right = min(r.right, t.left)
            elif dirx < 0:
                r.left = max(r.left, t.right)
        self.px = float(r.x)
        # vertical
        self.vy = min(self.vy + GRAV, MAXFALL)
        self.py += self.vy
        r = self.prect()
        grounded = False
        hits = self.solid_hits(r)
        if hits:
            if self.vy > 0:
                r.bottom = min(t.top for t in hits)
                grounded = True
            elif self.vy < 0:
                r.top = max(t.bottom for t in hits)
            self.vy = 0.0
            self.py = float(r.y)
        self.coyote = COYOTE if grounded else max(0, self.coyote - 1)
        self.jbuf = max(0, self.jbuf - 1)
        if self.jbuf > 0 and self.coyote > 0:
            self.vy = JUMPV
            self.coyote = self.jbuf = 0
            play(self.snd_jump)
        # crumbling blocks under feet
        if grounded:
            feet = pygame.Rect(r.left, r.bottom, PW, 2)
            for (tx, ty), c in self.crumbles.items():
                if c["t"] == -1 and not c["gone"] and \
                        feet.colliderect(pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)):
                    c["t"] = CRUMBLE_DELAY
        for (tx, ty), c in self.crumbles.items():
            if c["t"] > 0:
                c["t"] -= 1
                if c["t"] == 0:
                    c["gone"] = True
                    self.recent_crumble = 90
                    play(self.snd_crumb)
                    for _ in range(6):
                        self.particles.append(
                            [tx * TILE + TILE / 2, ty * TILE + TILE / 2,
                             random.uniform(-2, 2), random.uniform(-3, 1),
                             random.randint(20, 40), C_CRUMBLE])
        self.recent_crumble = max(0, self.recent_crumble - 1)
        # saws
        for s in self.saws:
            s["x"] += s["dir"] * SAW_SPEED
            if s["x"] <= s["min_x"]:
                s["x"], s["dir"] = s["min_x"], 1
            elif s["x"] >= s["max_x"]:
                s["x"], s["dir"] = s["max_x"], -1
            s["angle"] += 0.25 * s["dir"]
        # deaths
        hazbox = self.prect().inflate(-8, -6)
        if self.py > H + 40:
            self.kill("crumble" if self.recent_crumble > 0 else "fall")
            return
        for (tx, ty) in self.spikes:
            if hazbox.colliderect(pygame.Rect(tx * TILE + 6, ty * TILE + 12,
                                              TILE - 12, TILE - 12)):
                self.kill("spike", tile=(tx, ty))
                return
        t = self.frames / FPS
        for lz in self.lasers:
            phase = (t + lz["off"]) % LASER_PERIOD
            if phase >= LASER_PERIOD - LASER_ON:
                top = lz["ty"] * TILE + 12
                bottom = self.beam_bottom(lz)
                beam = pygame.Rect(lz["tx"] * TILE + TILE // 2 - 5, top, 10, bottom - top)
                if hazbox.colliderect(beam):
                    self.kill("laser")
                    return
        for i, s in enumerate(self.saws):
            dx = max(hazbox.left, min(s["x"], hazbox.right)) - s["x"]
            dy = max(hazbox.top, min(s["cy"], hazbox.bottom)) - s["cy"]
            if dx * dx + dy * dy < (SAW_R - 2) ** 2:
                self.kill("saw", saw_i=i)
                return
        # exit
        if self.prect().colliderect(self.exit_rect):
            play(self.snd_clear)
            self.state = "win" if self.li == len(LEVELS) - 1 else "clear"
            return
        self.frames += 1

    def beam_bottom(self, lz):
        for ty in range(lz["ty"] + 1, GH):
            if self.is_solid(lz["tx"], ty):
                return ty * TILE
        return H

    # ---- update / events
    def update(self):
        if self.state == "play":
            self.step_play()
        for p in self.particles:
            p[0] += p[2]
            p[1] += p[3]
            p[3] += 0.25
            p[4] -= 1
        self.particles = [p for p in self.particles if p[4] > 0]

    def event(self, e):
        if e.type == pygame.QUIT:
            self.running = False
            return
        if e.type != pygame.KEYDOWN and e.type != pygame.KEYUP:
            return
        jump_keys = (pygame.K_SPACE, pygame.K_UP, pygame.K_w)
        if self.state == "play":
            if e.type == pygame.KEYDOWN:
                if e.key in jump_keys:
                    self.jbuf = JBUF
                elif e.key == pygame.K_r:
                    self.reset_attempt()
                elif e.key == pygame.K_TAB:
                    self.state = "log"
            elif e.type == pygame.KEYUP and e.key in jump_keys and self.vy < 0:
                self.vy *= 0.45
        elif e.type == pygame.KEYDOWN:
            if self.state == "menu" and e.key == pygame.K_SPACE:
                self.load_level(0)
                self.state = "play"
            elif self.state == "lesson" and e.key == pygame.K_SPACE:
                self.reset_attempt()
                self.state = "play"
            elif self.state == "clear" and e.key == pygame.K_SPACE:
                self.load_level(self.li + 1)
                self.state = "play"
            elif self.state == "win" and e.key == pygame.K_r:
                self.reset_knowledge()
                self.state = "menu"
            elif self.state == "log" and e.key in (pygame.K_TAB, pygame.K_ESCAPE,
                                                   pygame.K_SPACE):
                self.state = "play"

    # ---- drawing
    def draw(self):
        s = self.screen
        s.fill(C_BG1)
        pygame.draw.rect(s, C_BG2, (0, H // 2, W, H // 2))
        tick = pygame.time.get_ticks() / 1000
        for x, y, b in self.stars:
            g = int(60 + 50 * b * (0.6 + 0.4 * math.sin(tick * 2 + x)))
            s.fill((g, g, min(255, g + 25)), (x, y, 2, 2))
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "win":
            self.draw_win()
        else:
            self.draw_world()
            if self.state == "lesson":
                self.draw_lesson()
            elif self.state == "clear":
                self.draw_clear()
            elif self.state == "log":
                self.draw_log()
        # particles on top of everything but overlay text is fine below them
        for p in self.particles:
            a = max(0, min(255, p[4] * 6))
            sz = 3 if p[4] > 20 else 2
            surf = pygame.Surface((sz, sz))
            surf.fill(p[5])
            surf.set_alpha(a)
            self.screen.blit(surf, (p[0], p[1]))

    def draw_world(self):
        s = self.screen
        k = self.know
        t = self.frames / FPS
        # solid tiles
        for (tx, ty) in self.solids:
            r = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
            pygame.draw.rect(s, C_TILE, r)
            pygame.draw.rect(s, C_TILE_TOP, (r.x, r.y, TILE, 3))
        # crumbling blocks
        for (tx, ty), c in self.crumbles.items():
            if c["gone"]:
                continue
            ox = random.randint(-2, 2) if c["t"] > 0 else 0
            r = pygame.Rect(tx * TILE + ox, ty * TILE, TILE, TILE)
            base = C_CRUMBLE if k["crumble"] else C_TILE
            pygame.draw.rect(s, base, r)
            pygame.draw.rect(s, C_TILE_TOP, (r.x, r.y, TILE, 3))
            crack = C_CRUMBLE_HI if k["crumble"] else (52, 58, 82)
            pygame.draw.line(s, crack, (r.x + 6, r.y + 8), (r.x + 14, r.y + 18), 2)
            pygame.draw.line(s, crack, (r.x + 14, r.y + 18), (r.x + 10, r.y + 26), 2)
            pygame.draw.line(s, crack, (r.x + 20, r.y + 5), (r.x + 24, r.y + 16), 2)
        # exit door
        er = self.exit_rect
        pygame.draw.rect(s, (30, 80, 45), er.inflate(8, 8), border_radius=6)
        pygame.draw.rect(s, C_EXIT, er, border_radius=4)
        pygame.draw.rect(s, (200, 255, 210), er, 2, border_radius=4)
        pygame.draw.circle(s, (30, 80, 45), (er.right - 8, er.centery), 3)
        txt = self.f_small.render("EXIT", True, (10, 40, 20))
        s.blit(txt, (er.centerx - txt.get_width() // 2, er.y + 6))
        # spikes: revealed ones drawn fully, hidden ones betrayed by a faint glint
        for (tx, ty) in self.spikes:
            bx, by = tx * TILE, (ty + 1) * TILE
            if (self.li, tx, ty) in k["spikes"]:
                for i in range(3):
                    x0 = bx + i * 10
                    pygame.draw.polygon(s, C_SPIKE,
                                        [(x0, by), (x0 + 10, by), (x0 + 5, by - 22)])
                    pygame.draw.polygon(s, (255, 150, 160),
                                        [(x0 + 3, by), (x0 + 5, by - 22), (x0 + 5, by)], 1)
            else:
                tw = 0.5 + 0.5 * math.sin(tick_now() * 2.6 + tx * 1.9)
                a = int(45 + 85 * tw)
                g = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
                for gx, gy, r_ in ((7, 22, 2), (16, 25, 3), (24, 20, 2)):
                    pygame.draw.line(g, (240, 244, 255, a), (gx - r_, gy), (gx + r_, gy), 1)
                    pygame.draw.line(g, (240, 244, 255, a), (gx, gy - r_), (gx, gy + r_), 1)
                s.blit(g, (bx, ty * TILE))
        # lasers
        for lz in self.lasers:
            ex, ey = lz["tx"] * TILE, lz["ty"] * TILE
            phase = (t + lz["off"]) % LASER_PERIOD
            firing = phase >= LASER_PERIOD - LASER_ON
            warning = (k["laser"] and
                       LASER_PERIOD - LASER_ON - LASER_WARN <= phase < LASER_PERIOD - LASER_ON)
            col = C_LASER if firing else ((255, 190, 90) if warning else (120, 60, 70))
            pygame.draw.rect(s, (60, 40, 55), (ex + 7, ey, TILE - 14, 14))
            pygame.draw.rect(s, col, (ex + 10, ey + 3, TILE - 20, 9))
            cx = ex + TILE // 2
            bottom = self.beam_bottom(lz)
            if firing:
                beam = pygame.Surface((14, bottom - ey - 12), pygame.SRCALPHA)
                beam.fill((255, 80, 80, 70))
                s.blit(beam, (cx - 7, ey + 12))
                pygame.draw.line(s, (255, 210, 210), (cx, ey + 12), (cx, bottom), 3)
            elif warning:
                for yy in range(ey + 16, bottom, 14):
                    pygame.draw.line(s, (255, 190, 90), (cx, yy), (cx, yy + 5), 1)
        # saws + revealed paths
        for i, sw in enumerate(self.saws):
            if (self.li, i) in k["saws"]:
                for xx in range(int(sw["min_x"]), int(sw["max_x"]), 16):
                    pygame.draw.circle(s, (200, 120, 130), (xx, int(sw["cy"])), 2)
            cx, cy = int(sw["x"]), int(sw["cy"])
            pygame.draw.circle(s, C_SAW, (cx, cy), SAW_R)
            for j in range(8):
                a = sw["angle"] + j * math.tau / 8
                pygame.draw.line(s, C_SAW, (cx, cy),
                                 (cx + math.cos(a) * (SAW_R + 5),
                                  cy + math.sin(a) * (SAW_R + 5)), 3)
            pygame.draw.circle(s, (90, 95, 110), (cx, cy), 5)
        # death markers (skulls)
        for (mx, my) in k["markers"].get(self.li, []):
            pygame.draw.circle(s, (120, 60, 70), (int(mx), int(my)), 6)
            s.fill((25, 15, 20), (int(mx) - 3, int(my) - 2, 2, 3))
            s.fill((25, 15, 20), (int(mx) + 1, int(my) - 2, 2, 3))
        # player
        if self.state in ("play", "clear", "log"):
            pr = self.prect()
            pygame.draw.rect(s, C_PLAYER, pr, border_radius=5)
            pygame.draw.rect(s, (200, 250, 255), pr, 2, border_radius=5)
            eye_dx = 5 if self.face >= 0 else -1
            s.fill((15, 30, 40), (pr.x + 4 + eye_dx, pr.y + 7, 3, 5))
            s.fill((15, 30, 40), (pr.x + 11 + eye_dx, pr.y + 7, 3, 5))
        self.draw_hud()
        if self.li == 0 and self.know["deaths"] == 0 and self.state == "play":
            tip = self.f_small.render("A / D or arrows to move  ·  SPACE to jump",
                                      True, C_DIM)
            s.blit(tip, (self.start[0] - 40, self.start[1] - 40))

    def draw_hud(self):
        s = self.screen
        lv = LEVELS[self.li]
        bar = pygame.Surface((W, 30), pygame.SRCALPHA)
        bar.fill((8, 9, 16, 200))
        s.blit(bar, (0, 0))
        prog = self.f_small.render(f"LEVEL {self.li + 1}/{len(LEVELS)}", True, C_GOLD)
        s.blit(prog, (12, 8))
        s.blit(self.f_small.render(lv["name"] + "  —  " + lv["hint"], True, C_TEXT),
               (12 + prog.get_width() + 14, 8))
        mid = self.f_small.render(
            f"LESSONS LEARNED: {len(self.know['lessons'])}", True, C_GOLD)
        s.blit(mid, (W // 2 - mid.get_width() // 2 + 130, 8))
        right = self.f_small.render("TAB lessons · R restart", True, C_DIM)
        s.blit(right, (W - right.get_width() - 12, 8))

    def panel(self, w_, h_):
        px, py = (W - w_) // 2, (H - h_) // 2
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        dim.fill((5, 6, 12, 190))
        self.screen.blit(dim, (0, 0))
        r = pygame.Rect(px, py, w_, h_)
        pygame.draw.rect(self.screen, (20, 22, 38), r, border_radius=12)
        pygame.draw.rect(self.screen, C_GOLD, r, 2, border_radius=12)
        return r

    def draw_lesson(self):
        r = self.panel(660, 300)
        s = self.screen
        h = self.f_h2.render(f"DEATH #{self.know['deaths']} — AND A NEW LESSON",
                             True, C_SPIKE)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 24))
        n, _ = self.know["lessons"][-1]
        sub = self.f_small.render(f"LESSON {n} OF YOUR CURRICULUM", True, C_DIM)
        s.blit(sub, (r.centerx - sub.get_width() // 2, r.y + 62))
        y = r.y + 96
        for line in wrap_text(self.lesson_text, self.f_body, r.w - 70):
            t = self.f_body.render(line, True, C_TEXT)
            s.blit(t, (r.centerx - t.get_width() // 2, y))
            y += 28
        if self.lesson_note:
            note = self.f_small.render(self.lesson_note, True, C_EXIT)
            s.blit(note, (r.centerx - note.get_width() // 2, y + 8))
        foot = self.f_small.render("SPACE — apply what you learned", True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 36))

    def draw_clear(self):
        r = self.panel(560, 200)
        s = self.screen
        h = self.f_h2.render(
            f"LEVEL {self.li + 1} OF {len(LEVELS)} CLEARED", True, C_EXIT)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 30))
        b = self.f_body.render(
            f"Deaths so far: {self.know['deaths']}   ·   "
            f"Lessons learned: {len(self.know['lessons'])}", True, C_TEXT)
        s.blit(b, (r.centerx - b.get_width() // 2, r.y + 85))
        foot = self.f_small.render("SPACE — descend further", True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 40))

    def draw_log(self):
        r = self.panel(760, 460)
        s = self.screen
        h = self.f_h2.render("YOUR CURRICULUM", True, C_GOLD)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 18))
        lessons = self.know["lessons"]
        y = r.y + 66
        shown = lessons[-9:]
        if not lessons:
            t = self.f_body.render("No lessons yet. The labyrinth awaits your "
                                   "first mistake.", True, C_DIM)
            s.blit(t, (r.centerx - t.get_width() // 2, y + 20))
        if len(lessons) > len(shown):
            t = self.f_small.render(f"… {len(lessons) - len(shown)} earlier "
                                    f"lessons remembered …", True, C_DIM)
            s.blit(t, (r.x + 34, y))
            y += 22
        for n, txt in shown:
            lines = wrap_text(f"{n}. {txt}", self.f_small, r.w - 68)
            for i, line in enumerate(lines[:2]):
                t = self.f_small.render(line + ("…" if i == 1 and len(lines) > 2 else ""),
                                        True, C_TEXT if n == lessons[-1][0] else C_DIM)
                s.blit(t, (r.x + 34, y))
                y += 18
            y += 6
        foot = self.f_small.render("TAB — back to the labyrinth", True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 30))

    def draw_menu(self):
        s = self.screen
        h = self.f_title.render("FAIL FORWARD", True, C_PLAYER)
        s.blit(h, (W // 2 - h.get_width() // 2, 110))
        sub = self.f_h2.render("every death teaches you something new", True, C_GOLD)
        s.blit(sub, (W // 2 - sub.get_width() // 2, 185))
        lines = [
            "The labyrinth hides its dangers. You will die — that is the point.",
            "Each death permanently reveals what killed you and grants a lesson",
            "you have never heard before. Nothing you learn is ever taken back.",
            "",
            "A / D or arrows — move      SPACE — jump      R — restart      TAB — lessons",
        ]
        y = 265
        for line in lines:
            t = self.f_body.render(line, True, C_TEXT if line else C_DIM)
            s.blit(t, (W // 2 - t.get_width() // 2, y))
            y += 30
        if (pygame.time.get_ticks() // 400) % 2:
            go = self.f_h2.render("PRESS SPACE TO FAIL", True, C_SPIKE)
            s.blit(go, (W // 2 - go.get_width() // 2, 440))

    def draw_win(self):
        s = self.screen
        h = self.f_title.render("LABYRINTH SOLVED", True, C_EXIT)
        s.blit(h, (W // 2 - h.get_width() // 2, 120))
        k = self.know
        lines = [
            f"You died {k['deaths']} times.",
            f"You learned {len(k['lessons'])} lessons.",
            "",
            "That was never failure. That was the curriculum.",
        ]
        y = 230
        for line in lines:
            t = self.f_h2.render(line, True, C_TEXT) if line else None
            if t:
                s.blit(t, (W // 2 - t.get_width() // 2, y))
            y += 44
        foot = self.f_body.render("R — run it back (the labyrinth forgets, too)",
                                  True, C_GOLD)
        s.blit(foot, (W // 2 - foot.get_width() // 2, 430))


def tick_now():
    return pygame.time.get_ticks() / 1000


# ---------------------------------------------------------------- main
async def main():
    validate_levels()
    try:
        pygame.mixer.pre_init(22050, -16, 1, 512)
    except Exception:
        pass
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Fail Forward")
    clock = pygame.time.Clock()
    g = Game(screen)
    while g.running:
        for e in pygame.event.get():
            g.event(e)
        g.update()
        g.draw()
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
    pygame.quit()


def selftest():
    """Headless smoke test: parse levels, run physics, verify the core promise —
    a death always produces a brand-new lesson."""
    validate_levels()
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    g = Game(screen)

    class Held(dict):
        def __getitem__(self, k):
            return dict.get(self, k, 0)

    for i in range(len(LEVELS)):
        g.load_level(i)
        g.state = "play"
        g.test_input = Held()
        for _ in range(120):
            g.update()
            g.draw()
        assert g.state in ("play", "lesson"), f"level {i}: unexpected state {g.state}"
        g.state = "play"
    # walking right on level 1 must eventually die and learn something
    g.reset_knowledge()
    g.load_level(0)
    g.state = "play"
    g.test_input = Held({pygame.K_RIGHT: 1})
    for _ in range(900):
        if g.state == "lesson":
            break
        g.update()
    assert g.state == "lesson", "expected a teaching death on level 1"
    assert len(g.know["lessons"]) == 1
    # every death yields a unique lesson, even after hundreds of deaths
    texts = [g.new_lesson(random.choice(list(CAUSE_LESSONS))) for _ in range(200)]
    assert len(set(texts)) == len(texts), "lessons repeated"
    pygame.quit()
    print("selftest OK — levels valid, physics stable, every death teaches "
          "a unique lesson")


if __name__ == "__main__":
    import sys
    import os
    if "--selftest" in sys.argv:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        selftest()
    else:
        asyncio.run(main())
