"""FAIL FORWARD — a 2D platformer where every death teaches you something new.

100 levels: 5 handcrafted + 95 procedurally generated (deterministic seeds).
New hazards unlock every 10 levels. Par grades, deathless badges, star shards,
unlockable avatars, power artifacts. Keyboard + touch. Pygame + stdlib only.
Web-ready via pygbag (async main loop).
"""
import asyncio
import json
import math
import os
import random
import sys
import array
import pygame

# ---------------------------------------------------------------- constants
TILE = 30
GW, GH = 32, 18
W, H = TILE * GW, TILE * GH          # 960 x 540
FPS = 60
GRAV, MAXFALL = 0.55, 12.0
MOVE = 4.2
JUMPV = -10.5
COYOTE, JBUF = 6, 8                   # frames of coyote time / jump buffer
CRUMBLE_DELAY = 21                    # ~0.35 s
LASER_PERIOD, LASER_ON, LASER_WARN = 2.1, 0.7, 0.35
SAW_SPEED, SAW_R = 2.2, 13
SENTRY_R = 12
BOLT_SPEED = 6.0
BOLT_PERIOD, BOLT_WARN = 156, 24      # frames (~2.6 s cycle)
FLICK_PERIOD, FLICK_SOLID, FLICK_WARN = 2.4, 1.5, 0.3   # seconds
PIST_PERIOD, PIST_DOWN, PIST_WARN, PIST_EXT = 3.0, 1.5, 0.3, 38
TOTAL_LEVELS = 100
WEB = sys.platform == "emscripten"
SAVE_KEY = "failforward_save"

# on-screen touch controls
BTN_L = pygame.Rect(16, H - 106, 92, 92)
BTN_R = pygame.Rect(124, H - 106, 92, 92)
BTN_J = pygame.Rect(W - 108, H - 106, 92, 92)

C_TILE = (42, 47, 69)
C_TILE_TOP = (74, 84, 124)
C_SPIKE = (225, 70, 90)
C_CRUMBLE = (150, 110, 70)
C_CRUMBLE_HI = (235, 170, 80)
C_LASER = (255, 80, 80)
C_SAW = (185, 190, 205)
C_SENTRY = (205, 120, 235)
C_BOLT = (255, 220, 120)
C_FLICK = (70, 160, 170)
C_PISTON = (120, 126, 142)
C_EXIT = (110, 230, 140)
C_TEXT = (225, 230, 245)
C_DIM = (140, 146, 170)
C_GOLD = (245, 205, 110)
C_SHARD = (255, 240, 180)

# the descent: background palette deepens every 10 levels
# (void blue -> violet drift -> abyssal teal-purple -> ember core)
PALETTES = [
    ((14, 15, 26), (22, 24, 40)),
    ((16, 14, 30), (26, 22, 46)),
    ((18, 13, 32), (30, 20, 48)),
    ((20, 12, 30), (36, 18, 44)),
    ((22, 12, 26), (40, 16, 38)),
    ((24, 11, 22), (44, 15, 30)),
    ((26, 10, 18), (48, 14, 24)),
    ((28, 10, 14), (52, 13, 18)),
    ((26, 9, 10), (56, 12, 14)),
    ((24, 8, 8), (62, 11, 10)),
]

GRADE_ORDER = {"C": 0, "B": 1, "A": 2, "S": 3}
GRADE_COLORS = {"S": C_GOLD, "A": (120, 230, 140), "B": (120, 190, 240),
                "C": (150, 150, 165)}

AVATARS = [
    {"name": "SPARK", "w": 20, "h": 26, "col": (90, 220, 235),
     "edge": (200, 250, 255), "need": 0},
    {"name": "EMBER", "w": 20, "h": 26, "col": (245, 150, 90),
     "edge": (255, 220, 180), "need": 5},
    {"name": "TITAN", "w": 26, "h": 32, "col": (130, 230, 150),
     "edge": (215, 255, 225), "need": 30},
    {"name": "WISP", "w": 16, "h": 20, "col": (205, 165, 255),
     "edge": (240, 228, 255), "need": 60},
]


def grade_for(deaths, par):
    if deaths == 0:
        return "S"
    if deaths <= par:
        return "A"
    if deaths <= par * 2:
        return "B"
    return "C"


# ---------------------------------------------------------------- levels
# '#' solid   '.' empty   'S' start   'E' exit   '^' hidden spike
# 'C' crumbling block     'L' laser emitter      'M' patrolling saw
# 'D' dropper   'V' sentinel   'T' turret   'F' phase tile
# 'P' piston spike   'A' shield charm   'J' feather sigil   'o' star shard
HAND_LEVELS = [
    {
        "name": "FIRST STEPS",
        "hint": "The floor is not always honest.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S.................^^.......E..",
            "#########...####################",
            "#########...####################",
            "#########...####################",
        ],
    },
    {
        "name": "CRACKS IN THE PATH",
        "hint": "Some floors hold grudges.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S............^............E...",
            "######CCCCC######CCCC###CCC#####",
            "######.....######....###...#####",
            "######.....######....###...#####",
        ],
    },
    {
        "name": "THE RHYTHM SECTION",
        "hint": "Keep perfect time.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "....########################....",
            "......L....L....L....L....L.....",
            "................................",
            "................................",
            "................................",
            "................................",
            "..S...........................E.",
            "################################",
            "################################",
            "################################",
        ],
    },
    {
        "name": "THE PATROL",
        "hint": "The saws never rest. Use their rhythm.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            ".E..................M...........",
            "####CCCC####################....",
            "................................",
            ".............................###",
            "..S.............M...............",
            "################################",
            "################################",
            "################################",
        ],
    },
    {
        "name": "GRADUATION",
        "hint": "Everything, all at once.",
        "map": [
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "................................",
            "..........############..........",
            "............L..L..L.............",
            "................................",
            "................................",
            "................................",
            "................................",
            ".S.....^^.............M...^^..E.",
            "##########CCCC...###############",
            "##########.......###############",
            "##########.......###############",
        ],
    },
]

GEN_NAMES = [
    "THE SHALLOWS", "DRIP CORRIDOR", "COLD STORAGE", "THE UNDERCROFT",
    "HUMMING HALLS", "BLADE GARDEN", "THE LONG WALK", "GLASS FLOOR",
    "WIDOW'S GAP", "THE METRONOME", "ASH ALLEY", "QUIET RUIN",
    "SPARK CELLAR", "THE FURNACE", "LOW CEILING", "ECHO SPAN",
    "THE SIEVE", "RUST BELT", "DEEP STACKS", "THE CRUCIBLE",
]

GEN_HINTS = [
    "Deeper now. Watch before you walk.",
    "The labyrinth is listening.",
    "Old lessons still apply.",
    "Nothing here is new. Only meaner.",
    "Trust the glint.",
    "The rhythm never lies.",
    "Patience is a movement tech.",
    "The floor remembers you.",
    "Every scar on this map is yours.",
    "Speed kills. Usually you.",
    "One more room. Then one more.",
    "The exit is closer than it looks.",
]

SEG_W = {"spikes1": 3, "spikes2": 4, "spikes3": 5, "gap2": 2, "gap3": 3,
         "gap4": 4, "crumble3": 3, "crumble4": 4, "laser": 5, "saw": 7,
         "platgap": 7, "lasercrumble": 6, "dropper": 5, "sentry": 4,
         "turret": 6, "flicker": 4, "laserpair": 7, "sawduo": 9,
         "dropcluster": 7, "piston": 4}

# the new hazard each decade introduces (forced into every level of it)
INTRO_SEG = {21: "dropper", 31: "sentry", 41: "turret", 51: "flicker",
             61: "laserpair", 71: "sawduo", 81: "dropcluster"}


def gen_level(ix):
    """Deterministically generate level ix (0-based). Solvable by construction:
    gaps <= 4 tiles, wider pits get a floating platform, saws are penned
    between hop-over bollards, turret bolt lanes end at a bollard, and every
    hazard segment is followed by one guaranteed flat column. New hazard types
    unlock by decade (see INTRO_SEG); sky bricks appear from level 11,
    piston spikes from 16, artifacts from 13, shards throughout."""
    rng = random.Random(ix * 7919 + 13)
    lvl = ix + 1
    d = min(3, max(0, (ix - 5) * 4 // (TOTAL_LEVELS - 5)))
    support = ["#"] * GW              # row 15: '#', 'C', 'F' or '.' (pit)
    entity = ["."] * GW               # row 14: '^', 'M', 'P', '#' bollard
    plat_row = [0] * GW
    ceil = ["."] * GW                 # '#' ceiling block at row 8
    laser_cols = set()
    drop_cols = set()
    sentry_cols = set()
    turret_cols = set()
    brick12 = {}
    brick11 = {}

    pool = ["flat", "flat", "spikes1", "gap2", "crumble3"]
    if d >= 1:
        pool += ["spikes2", "gap3", "laser", "crumble4"]
    if d >= 2:
        pool += ["spikes3", "gap4", "saw", "platgap", "laser"]
    if d >= 3:
        pool += ["saw", "platgap", "lasercrumble", "spikes3", "gap4"]
    if lvl >= 16:
        pool += ["piston"]
    if lvl >= 21:
        pool += ["dropper"]
    if lvl >= 31:
        pool += ["sentry"]
    if lvl >= 41:
        pool += ["turret"]
    if lvl >= 51:
        pool += ["flicker"]
    if lvl >= 61:
        pool += ["laserpair"]
    if lvl >= 71:
        pool += ["sawduo"]
    if lvl >= 81:
        pool += ["dropcluster"]
    if lvl >= 91:                     # max density: flat becomes rare
        pool = [o for o in pool if o != "flat"] + ["flat"]

    state = {"cur": 3}
    end = 28

    def place(seg):
        cur = state["cur"]
        if seg == "flat":
            state["cur"] = cur + rng.randint(1, 2)
            return
        if seg.startswith("spikes"):
            for i in range(int(seg[-1])):
                entity[cur + 1 + i] = "^"
        elif seg.startswith("gap"):
            for c in range(cur, cur + int(seg[-1])):
                support[c] = "."
        elif seg.startswith("crumble"):
            for c in range(cur, cur + int(seg[-1])):
                support[c] = "C"
        elif seg == "laser":
            for c in (cur + 1, cur + 2, cur + 3):
                ceil[c] = "#"
            laser_cols.add(cur + 2)
        elif seg == "laserpair":
            for c in range(cur + 1, cur + 6):
                ceil[c] = "#"
            laser_cols.add(cur + 2)
            laser_cols.add(cur + 4)
        elif seg == "saw":
            entity[cur] = "#"
            entity[cur + 3] = "M"
            entity[cur + 6] = "#"
        elif seg == "sawduo":
            entity[cur] = "#"
            entity[cur + 3] = "M"
            entity[cur + 5] = "M"
            entity[cur + 8] = "#"
        elif seg == "platgap":
            for c in range(cur + 1, cur + 6):
                support[c] = "."
            plat_row[cur + 3] = plat_row[cur + 4] = 12
        elif seg == "lasercrumble":
            for c in range(cur + 1, cur + 5):
                support[c] = "C"
            for c in (cur + 1, cur + 2, cur + 3):
                ceil[c] = "#"
            laser_cols.add(cur + 2)
        elif seg == "dropper":
            drop_cols.add(cur + 1)
            drop_cols.add(cur + 3)
        elif seg == "dropcluster":
            drop_cols.add(cur + 1)
            drop_cols.add(cur + 3)
            drop_cols.add(cur + 5)
        elif seg == "sentry":
            sentry_cols.add(cur + 2)
        elif seg == "turret":
            entity[cur] = "#"
            entity[cur + 4] = "#"
            turret_cols.add(cur + 4)
        elif seg == "flicker":
            for c in range(cur, cur + 4):
                support[c] = "F"
        elif seg == "piston":
            entity[cur + 1] = "P"
            entity[cur + 2] = "P"
        state["cur"] = cur + SEG_W[seg] + 1   # +1 flat guard column

    decade = ((lvl - 1) // 10) * 10 + 1
    intro = INTRO_SEG.get(decade)
    if intro:
        place("flat")
        place(intro)
    if decade == 11 and lvl >= 16:
        place("piston")
    while state["cur"] <= end:
        cur = state["cur"]
        opts = [o for o in pool if o == "flat" or cur + SEG_W[o] <= end + 1]
        place(rng.choice(opts))

    # sky bricks (level 11+): an aerial route over the danger below.
    # Over spikes they are a lucky roll, never a guarantee.
    if lvl >= 11:
        c = 3
        while c <= end:
            if entity[c] == "^":
                r0 = c
                while c < GW and entity[c] == "^":
                    c += 1
                mid = (r0 + c - 1) // 2
                if ceil[mid] != "#" and mid not in laser_cols \
                        and rng.random() < 0.55:
                    brick12[mid] = "C" if (lvl >= 31 and rng.random() < 0.6) else "#"
            else:
                c += 1
        for c in range(GW):
            if entity[c] == "M" and ceil[c] != "#":
                brick11[c] = "C" if (lvl >= 41 and rng.random() < 0.6) else "#"

    grid = [["."] * GW for _ in range(GH)]
    for c in range(GW):
        if c in drop_cols:
            grid[5][c] = "D"
        if ceil[c] == "#":
            grid[8][c] = "#"
        if c in laser_cols:
            grid[9][c] = "L"
        if c in sentry_cols:
            grid[10][c] = "V"
        if c in brick11:
            grid[11][c] = brick11[c]
        if c in brick12:
            grid[12][c] = brick12[c]
        if c in turret_cols:
            grid[13][c] = "T"
        if plat_row[c]:
            grid[plat_row[c]][c] = "#"
        if entity[c] != ".":
            grid[14][c] = entity[c]
        if support[c] == "#":
            grid[15][c] = grid[16][c] = grid[17][c] = "#"
        elif support[c] in "CF":
            grid[15][c] = support[c]

    # power artifact (level 13+, sometimes): shield charm or feather sigil
    if lvl >= 13 and rng.random() < 0.35:
        cands = [c for c in range(5, 28)
                 if support[c] == "#" and entity[c] == "." and grid[12][c] == "."
                 and c not in laser_cols and c not in drop_cols
                 and c not in sentry_cols]
        if cands:
            grid[12][rng.choice(cands)] = "A" if rng.random() < 0.5 else "J"

    # star shards: 2-3 scattered pickups, often hovering over danger
    for _ in range(rng.randint(2, 3)):
        for _try in range(14):
            c = rng.randint(4, 28)
            r = rng.choice((11, 12, 13))
            if grid[r][c] == "." and grid[r - 1][c] == ".":
                grid[r][c] = "o"
                break

    grid[14][1] = "S"
    grid[14][30] = "E"
    return {"name": rng.choice(GEN_NAMES), "hint": rng.choice(GEN_HINTS),
            "map": ["".join(r) for r in grid]}


_LEVEL_CACHE = {}


def level_data(ix):
    if ix not in _LEVEL_CACHE:
        _LEVEL_CACHE[ix] = (HAND_LEVELS[ix] if ix < len(HAND_LEVELS)
                            else gen_level(ix))
    return _LEVEL_CACHE[ix]


def _runs(s, chars):
    n, run = 0, 0
    for ch in s:
        if ch in chars:
            run += 1
            if run == 1:
                n += 1
        else:
            run = 0
    return n


def compute_par(m):
    """Expected-deaths budget for a level, from its hazard census."""
    flat = "".join(m)
    score = (_runs(m[14], "^") * 1.0 + flat.count("M") * 1.0 +
             flat.count("L") * 0.8 + flat.count("D") * 0.6 +
             flat.count("V") * 1.2 + flat.count("T") * 1.2 +
             flat.count("P") * 0.8 +
             _runs(m[15], "C") * 0.6 + _runs(m[15], "F") * 0.8 +
             _runs(m[15], ".") * 0.5)
    return max(1, min(9, round(score * 0.7)))


# ---------------------------------------------------------------- lessons
# Every death yields a lesson the player has never seen before.
CAUSE_LESSONS = {
    "spike": [
        "Spikes hide beneath a faint glint on the floor. That shimmer you walked "
        "past was the warning. Every spike you find is revealed permanently — "
        "and now you know what the glint means.",
        "Spikes love doorsteps. The closer you are to an exit, the more suspicious "
        "the floor should feel.",
        "Revealed spikes are just terrain now. Clear them with a full jump — "
        "your jump crests at about three blocks high.",
    ],
    "crumble": [
        "Cracked blocks crumble about a third of a second after you touch them. "
        "Never stop on a bridge. From now on, crumbling blocks are highlighted in amber for you.",
        "Crumbled blocks rebuild every time you restart. A broken bridge is only "
        "broken for the rest of this attempt.",
    ],
    "laser": [
        "Lasers fire on a fixed rhythm — calm, then a burst of fire, forever. "
        "From now on, emitters glow just before firing. Walk to the beat.",
        "Deeper lasers hop to a new column after every burst. The beat stays "
        "honest — the ground it strikes does not.",
        "Neighboring lasers fire in sequence, one after another. Chase the wave — "
        "stay right behind a beam that just switched off.",
    ],
    "saw": [
        "Saws patrol a fixed route at a fixed speed — this one's path is now marked "
        "for you. They never speed up and never turn around early.",
        "You can jump clean over a saw. Let it come to you, hop it, and use the "
        "safe time behind it.",
        "A saw cannot pass the small raised blocks that pen it in. Stand beyond "
        "the bollard and the blade is just scenery.",
    ],
    "fall": [
        "The pits are bottomless. A skull now marks where you fell — the labyrinth "
        "remembers your mistakes so you don't have to.",
        "There is no fall damage, and falling has a top speed. Drops never hurt — "
        "only what is at the bottom does.",
        "A gap wider than a jump always offers a perch. Look for the floating "
        "slab before you look for a eulogy.",
    ],
    "dropper": [
        "Stalactites drop the moment you linger beneath them. A walker outruns "
        "the fall — a hesitater wears it. Armed droppers now show their "
        "trigger zone.",
        "No two droppers fall alike — some drift down lazily, some drop like "
        "anvils. Each one keeps its own weight forever.",
        "Droppers re-arm every time you restart. The ceiling never runs out "
        "of teeth.",
    ],
    "sentry": [
        "Sentinels sweep a fixed vertical lane, each at its own constant pace. "
        "Watch one full sweep, then slip past near the top of its climb. "
        "This one's lane is now drawn.",
        "Some sentinels drift and some dive, but none ever changes speed "
        "mid-sweep. One step to the side and it is just a lamp.",
    ],
    "bolt": [
        "Turrets fire on a steady clock, and the muzzle glows before every shot. "
        "Bolts fly at shin height — skip them like a jump rope. Bolt lanes are "
        "now marked for you.",
        "Bolts die on the first wall they meet. Stand behind a bollard and let "
        "the turret waste its breath.",
    ],
    "flicker": [
        "Phase tiles repeat one honest cycle: solid, flashing, gone. The flash "
        "is your last chance to leave. Cross with the wave, never against it.",
        "Phase tiles vanish on schedule, not on touch. Unlike crumbling stone, "
        "they always come back — patience rebuilds this bridge.",
    ],
    "piston": [
        "Piston spikes breathe on a cycle: sleeping steel, a rattle, then a "
        "blade too tall to clear. The rattle is your cue — cross while the "
        "steel sleeps.",
        "A piston's timing never changes and its base is always visible. If "
        "you died to one, you crossed on the wrong beat, not the wrong tile.",
    ],
}

GENERAL_LESSONS = [
    "Coyote time: for a split second after running off an edge, you can still jump. "
    "The ledge forgives hesitation — briefly.",
    "Jump buffering: press jump just before you land and it fires the instant you "
    "touch ground. Trust the rhythm, not the reflex.",
    "Release the jump key early for a shorter hop. Small jumps are safer under "
    "low ceilings and near hazards.",
    "Your hazard hitbox is smaller than your body. A near miss that looks fatal "
    "often isn't — commit to tight gaps.",
    "Press R — or tap RESTART — to restart an attempt instantly. Sometimes "
    "resetting the saws and lasers is the smartest move you have.",
    "Press TAB — or tap LESSONS — at any time to reread every lesson you have learned.",
    "Everything you reveal — spikes, paths, warnings — stays revealed for your "
    "whole run. Dying makes the labyrinth more honest.",
    "The exit door only needs a touch. You can brush it mid-air; nobody is "
    "grading your landing.",
    "Sky bricks float above some dangers — an aerial route for those who look up. "
    "Never count on one: the labyrinth grants them at random, and the cracked "
    "ones crumble.",
    "A gold charm forgives exactly one wound per attempt. A feather sigil grants "
    "a second jump in mid-air. Powers last until you die.",
    "Star shards are forever — death cannot take a shard you have touched. "
    "Gather them to take new forms, some larger, some smaller.",
    "You reach full speed instantly and stop instantly. Your movement is exact — "
    "hesitation, not control, is the enemy.",
    "Blades and beams follow perfect clocks. Watch one full cycle before you "
    "commit — the pattern never lies.",
    "Hazards reset when you do. Every attempt starts with the same positions "
    "and the same beats, so a timing that worked once works forever.",
    "Skulls mark every place you have died. A cluster of skulls is a lesson "
    "somebody refused to learn.",
    "Clear a level without dying to earn its deathless badge. Par is printed "
    "at the top — beat it for an A, miss it twice over for a C.",
    "Every tenth level, the labyrinth learns a new trick. So should you.",
    "The sky is bleeding redder the deeper you go. The labyrinth is sinking "
    "toward the ember core — reach level 100 before it does.",
    "Your furthest level, grades and shards are saved. Close the game, come "
    "back tomorrow — the labyrinth keeps your place.",
    "Deaths here are lessons, not losses. The counter at the top is not a score — "
    "it is a curriculum.",
]

WISDOM = [
    "Watch first. Move second.",
    "Patience beats reflexes when the pattern is fixed.",
    "The fastest route is the one you have already died on.",
    "Fear the floor you have not tested.",
    "Mastery is a long list of survived mistakes.",
    "The labyrinth is out of secrets. Now it is only you against your own hurry.",
]

REVEAL_NOTES = {
    "spike": "+ Spikes revealed on your map, permanently.",
    "crumble": "+ All crumbling blocks are now highlighted.",
    "laser": "+ Laser emitters now glow before firing.",
    "saw": "+ This saw's patrol route is now drawn.",
    "fall": "+ A skull marks the spot.",
    "dropper": "+ Dropper trigger zones are now shown.",
    "sentry": "+ This sentinel's lane is now drawn.",
    "bolt": "+ Turret bolt lanes are now marked.",
    "flicker": "+ You now know the phase cycle: 1.5s solid, flash, 0.6s gone.",
    "piston": "+ You now know the cycle: 1.5s asleep, a rattle, 1.2s of blade.",
}


# ---------------------------------------------------------------- audio
def make_sound(freq, dur, vol=0.25, kind="square", slide=0.0):
    try:
        sr = 22050
        n = int(sr * dur)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            f = freq + slide * t
            env = min(1.0, 6.0 * (1 - i / n))
            if kind == "square":
                v = 1.0 if (t * f) % 1 < 0.5 else -1.0
            elif kind == "noise":
                v = random.uniform(-1, 1)
            else:
                v = math.sin(2 * math.pi * f * t)
            buf.append(int(v * env * vol * 32767))
        return pygame.mixer.Sound(buffer=buf.tobytes())
    except Exception:
        return None


def play(snd):
    if snd:
        try:
            snd.play()
        except Exception:
            pass


# ---------------------------------------------------------------- helpers
def wrap_text(text, font, width):
    words, lines, cur = text.split(" "), [], ""
    for w_ in words:
        trial = (cur + " " + w_).strip()
        if font.size(trial)[0] <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    return lines


def _save_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "save.txt")


def load_progress():
    raw = None
    try:
        if WEB:
            import platform as pf
            raw = pf.window.localStorage.getItem(SAVE_KEY)
            if raw is None:
                raw = pf.window.localStorage.getItem("failforward_unlocked")
        else:
            with open(_save_path()) as f:
                raw = f.read()
    except Exception:
        pass
    prog = {"unlocked": 1, "best": {}, "shards": [], "avatar": 0}
    if raw is not None:
        try:
            data = json.loads(str(raw))
            prog["unlocked"] = max(1, min(TOTAL_LEVELS,
                                          int(data.get("unlocked", 1))))
            prog["best"] = {k: v for k, v in dict(data.get("best", {})).items()
                            if v in GRADE_ORDER}
            prog["shards"] = [str(x) for x in list(data.get("shards", []))]
            prog["avatar"] = int(data.get("avatar", 0)) % len(AVATARS)
        except Exception:
            try:
                prog["unlocked"] = max(1, min(TOTAL_LEVELS, int(str(raw).strip())))
            except Exception:
                pass
    if AVATARS[prog["avatar"]]["need"] > len(prog["shards"]):
        prog["avatar"] = 0
    return prog


def save_progress(prog):
    try:
        data = json.dumps(prog)
        if WEB:
            import platform as pf
            pf.window.localStorage.setItem(SAVE_KEY, data)
        else:
            with open(_save_path(), "w") as f:
                f.write(data)
    except Exception:
        pass


def validate_levels():
    for ix in range(TOTAL_LEVELS):
        m = level_data(ix)["map"]
        assert len(m) == GH, f"level {ix}: {len(m)} rows"
        for r, row in enumerate(m):
            assert len(row) == GW, f"level {ix} row {r}: {len(row)} cols"
        flat = "".join(m)
        assert flat.count("S") == 1 and flat.count("E") == 1, f"level {ix}: S/E"
        assert 1 <= compute_par(m) <= 9, f"level {ix}: par out of range"
        # pits wider than a jump must offer a platform perch
        run = 0
        for c in range(GW):
            if m[15][c] in "#CF":
                run = 0
                continue
            run += 1
            if run > 4:
                ok = any(m[r][cc] == "#"
                         for r in (11, 12, 13)
                         for cc in range(max(0, c - 6), c + 1))
                assert ok, f"level {ix}: unjumpable pit ending col {c}"
        # hazard runs must stay clearable
        for row, ch, cap in ((m[14], "^", 3), (m[15], "F", 4), (m[14], "P", 2)):
            run = 0
            for c in range(GW):
                if row[c] == ch:
                    run += 1
                    assert run <= cap, f"level {ix}: {ch} run too long at {c}"
                else:
                    run = 0


# ---------------------------------------------------------------- game
class Game:
    def __init__(self, screen):
        self.screen = screen
        self.f_title = pygame.font.Font(None, 76)
        self.f_h2 = pygame.font.Font(None, 40)
        self.f_body = pygame.font.Font(None, 26)
        self.f_small = pygame.font.Font(None, 20)
        self.snd_jump = make_sound(320, 0.12, 0.14, "square", slide=400)
        self.snd_die = make_sound(180, 0.35, 0.22, "noise")
        self.snd_lesson = make_sound(520, 0.28, 0.16, "sine", slide=260)
        self.snd_clear = make_sound(440, 0.4, 0.18, "square", slide=440)
        self.snd_crumb = make_sound(120, 0.15, 0.15, "noise")
        self.snd_pick = make_sound(660, 0.2, 0.15, "sine", slide=350)
        self.snd_shard = make_sound(880, 0.12, 0.13, "sine", slide=200)
        random.seed(7)
        self.stars = [(random.randrange(W), random.randrange(H), random.random())
                      for _ in range(90)]
        self.running = True
        self.state = "menu"
        self.test_input = None
        # touch / pointer state
        self.show_touch = WEB
        self.touch = {"left": set(), "right": set(), "jump": set()}
        self._tap_ms = -10000
        self.hud_log_r = pygame.Rect(0, 0, 0, 0)
        self.hud_reset_r = pygame.Rect(0, 0, 0, 0)
        self.m_left_r = pygame.Rect(W // 2 - 248, 398, 56, 48)
        self.m_right_r = pygame.Rect(W // 2 + 192, 398, 56, 48)
        self.m_avatar_rs = []
        # persistent progress (survives closing the game)
        self.prog = load_progress()
        self.unlocked = self.prog["unlocked"]
        self.last_grade = "C"
        self.toast = None            # (text, frames_left)
        self.reset_knowledge()

    @property
    def avatar(self):
        return AVATARS[self.prog["avatar"]]

    def shard_count(self):
        return len(self.prog["shards"])

    # ---- persistent knowledge (survives deaths and levels, not full resets)
    def reset_knowledge(self):
        self.know = {
            "spikes": set(),
            "crumble": False,
            "laser": False,
            "saws": set(),
            "dropper": False,
            "sentries": set(),
            "bolt": False,
            "flicker": False,
            "piston": False,
            "deaths": 0,
            "lessons": [],
            "seen": set(),
            "markers": {},
            "wisdom_n": 0,
        }
        self.particles = []
        self.li = 0
        self.menu_sel = self.unlocked

    # ---- level lifecycle
    def load_level(self, i):
        self.li = i
        self.lvdata = level_data(i)
        m = self.lvdata["map"]
        self.par = compute_par(m)
        self.level_deaths = 0
        self.solids = set()
        self.spikes = set()
        self.crumbles = {}
        self.flickers = {}
        self.lasers = []
        self.saws = []
        self.droppers = []
        self.sentries = []
        self.turrets = []
        self.pistons = []
        self.all_artifacts = []
        self.level_shards = set()
        self.bolts = []
        self.start_tile = (2, 14)
        self.exit_rect = pygame.Rect(0, 0, TILE, TILE)
        for y, row in enumerate(m):
            for x, c in enumerate(row):
                if c == "#":
                    self.solids.add((x, y))
                elif c == "C":
                    self.crumbles[(x, y)] = {"t": -1, "gone": False}
                elif c == "F":
                    self.flickers[(x, y)] = (x % 7) * 0.25
                elif c == "^":
                    self.spikes.add((x, y))
                elif c == "L":
                    self.lasers.append({"tx": x, "ty": y,
                                        "off": len(self.lasers) * 0.7})
                elif c == "M":
                    self.saws.append({"tx": x, "ty": y})
                elif c == "D":
                    self.droppers.append({"tx": x, "ty": y})
                elif c == "V":
                    self.sentries.append({"tx": x, "ty": y})
                elif c == "T":
                    self.turrets.append({"tx": x, "ty": y})
                elif c == "P":
                    self.pistons.append({"tx": x, "ty": y,
                                         "off": (x % 5) * 0.45})
                elif c == "A":
                    self.all_artifacts.append({"tx": x, "ty": y, "kind": "shield"})
                elif c == "J":
                    self.all_artifacts.append({"tx": x, "ty": y, "kind": "feather"})
                elif c == "o":
                    self.level_shards.add((x, y))
                elif c == "S":
                    self.start_tile = (x, y)
                elif c == "E":
                    self.exit_rect = pygame.Rect(x * TILE + 3, (y - 1) * TILE + 6,
                                                 TILE - 6, 2 * TILE - 8)
        # saw patrol ranges: extend while the tile below is solid ground
        for s in self.saws:
            def supported(tx, ty=s["ty"]):
                below = (tx, ty + 1)
                return below in self.solids or below in self.crumbles
            lx = rx = s["tx"]
            while lx - 1 >= 0 and (lx - 1, s["ty"]) not in self.solids and supported(lx - 1):
                lx -= 1
            while rx + 1 < GW and (rx + 1, s["ty"]) not in self.solids and supported(rx + 1):
                rx += 1
            s["min_x"] = lx * TILE + SAW_R
            s["max_x"] = (rx + 1) * TILE - SAW_R
            s["home"] = s["tx"] * TILE + TILE / 2
            s["cy"] = s["ty"] * TILE + TILE / 2
            s["angle"] = 0.0
        # per-instance character: sentinel pace, dropper weight and reach,
        # all deterministic for this level forever
        rngv = random.Random(i * 31337 + 7)
        for v in self.sentries:
            top = bot = v["ty"]
            while top - 1 >= 2 and (v["tx"], top - 1) not in self.solids:
                top -= 1
            while bot + 1 <= 14 and (v["tx"], bot + 1) not in self.solids:
                bot += 1
            v["min_y"] = top * TILE + SENTRY_R
            v["max_y"] = (bot + 1) * TILE - SENTRY_R
            v["cx"] = v["tx"] * TILE + TILE / 2
            v["home"] = v["ty"] * TILE + TILE / 2
            v["spd"] = 1.4 + rngv.random() * 1.8
        for dr in self.droppers:
            dr["grav"] = 0.38 + rngv.random() * 0.5
            dr["trig"] = 32 + rngv.random() * 22
        # generated levels: lasers hop between the columns of their arch
        for lz in self.lasers:
            if i >= len(HAND_LEVELS):
                cols = [c for c in (lz["tx"] - 1, lz["tx"], lz["tx"] + 1)
                        if 0 <= c < GW and (c, lz["ty"] - 1) in self.solids
                        and (c, lz["ty"]) not in self.solids]
                lz["cols"] = cols or [lz["tx"]]
            else:
                lz["cols"] = [lz["tx"]]
        self.reset_attempt()

    def reset_attempt(self):
        av = self.avatar
        self.pw, self.ph = av["w"], av["h"]
        sx, sy = self.start_tile
        self.start = (sx * TILE + (TILE - self.pw) // 2,
                      sy * TILE + TILE - self.ph)
        self.px, self.py = float(self.start[0]), float(self.start[1])
        self.vy = 0.0
        self.face = 1
        self.coyote = self.jbuf = 0
        self.frames = 0
        self.recent_crumble = 0
        self.recent_flicker = 0
        self.shield = False
        self.feather = False
        self.air_extra = 0
        self.invuln = 0
        self.artifacts = list(self.all_artifacts)
        for c in self.crumbles.values():
            c["t"], c["gone"] = -1, False
        for s in self.saws:
            s["x"], s["dir"] = s["home"], 1
        for v in self.sentries:
            v["y"], v["dir"] = v["home"], 1
        for dr in self.droppers:
            dr["y"] = dr["ty"] * TILE + 4.0
            dr["vy"] = 0.0
            dr["state"] = "armed"
        self.bolts = []
        for s_ in self.touch.values():
            s_.clear()

    def set_toast(self, text):
        self.toast = (text, 170)

    # ---- lesson machinery: guaranteed-new lesson on every death
    def new_lesson(self, cause):
        for txt in CAUSE_LESSONS.get(cause, []):
            if txt not in self.know["seen"]:
                self.know["seen"].add(txt)
                return txt
        for txt in GENERAL_LESSONS:
            if txt not in self.know["seen"]:
                self.know["seen"].add(txt)
                return txt
        self.know["wisdom_n"] += 1
        n = self.know["wisdom_n"]
        txt = f"Wisdom #{n}: {WISDOM[(n - 1) % len(WISDOM)]}"
        self.know["seen"].add(txt)
        return txt

    def reveal_spike_group(self, tx, ty):
        stack = [(tx, ty)]
        while stack:
            x, y = stack.pop()
            if (x, y) not in self.spikes or (self.li, x, y) in self.know["spikes"]:
                continue
            self.know["spikes"].add((self.li, x, y))
            stack += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

    def kill(self, cause, tile=None, idx=None):
        if self.state != "play":
            return
        if self.shield and cause not in ("fall", "crumble", "flicker"):
            self.shield = False
            self.invuln = 75
            self.vy = min(self.vy, -6.0)
            self.set_toast("the charm shatters — one death forgiven")
            play(self.snd_crumb)
            cx, cy = self.px + self.pw / 2, self.py + self.ph / 2
            for _ in range(14):
                a = random.uniform(0, math.tau)
                sp = random.uniform(1, 5)
                self.particles.append([cx, cy, math.cos(a) * sp,
                                       math.sin(a) * sp - 1,
                                       random.randint(20, 45), C_GOLD])
            return
        k = self.know
        k["deaths"] += 1
        self.level_deaths += 1
        cx, cy = self.px + self.pw / 2, min(self.py + self.ph / 2, H - 10)
        k["markers"].setdefault(self.li, []).append((cx, cy))
        revealed_new = False
        if cause == "spike" and tile:
            before = len(k["spikes"])
            self.reveal_spike_group(*tile)
            revealed_new = len(k["spikes"]) > before
        elif cause == "crumble" and not k["crumble"]:
            k["crumble"] = revealed_new = True
        elif cause == "laser" and not k["laser"]:
            k["laser"] = revealed_new = True
        elif cause == "saw" and idx is not None:
            revealed_new = (self.li, idx) not in k["saws"]
            k["saws"].add((self.li, idx))
        elif cause == "sentry" and idx is not None:
            revealed_new = (self.li, idx) not in k["sentries"]
            k["sentries"].add((self.li, idx))
        elif cause == "dropper" and not k["dropper"]:
            k["dropper"] = revealed_new = True
        elif cause == "bolt" and not k["bolt"]:
            k["bolt"] = revealed_new = True
        elif cause == "flicker" and not k["flicker"]:
            k["flicker"] = revealed_new = True
        elif cause == "piston" and not k["piston"]:
            k["piston"] = revealed_new = True
        elif cause == "fall":
            revealed_new = True  # the skull marker itself
        text = self.new_lesson(cause)
        k["lessons"].append((len(k["lessons"]) + 1, text))
        self.lesson_text = text
        self.lesson_note = REVEAL_NOTES[cause] if revealed_new else ""
        for _ in range(24):
            a = random.uniform(0, math.tau)
            sp = random.uniform(1, 6)
            self.particles.append([cx, cy, math.cos(a) * sp, math.sin(a) * sp - 2,
                                   random.randint(30, 60), C_SPIKE])
        play(self.snd_die)
        play(self.snd_lesson)
        self.state = "lesson"

    # ---- physics & hazards
    def flicker_solid(self, off):
        ph = (self.frames / FPS + off) % FLICK_PERIOD
        return ph < FLICK_SOLID + FLICK_WARN

    def is_solid(self, tx, ty):
        if (tx, ty) in self.solids:
            return True
        c = self.crumbles.get((tx, ty))
        if c is not None and not c["gone"]:
            return True
        off = self.flickers.get((tx, ty))
        return off is not None and self.flicker_solid(off)

    def prect(self):
        return pygame.Rect(int(self.px), int(self.py), self.pw, self.ph)

    def solid_hits(self, r):
        out = []
        for ty in range(max(0, r.top // TILE), min(GH - 1, (r.bottom - 1) // TILE) + 1):
            for tx in range(max(0, r.left // TILE), min(GW - 1, (r.right - 1) // TILE) + 1):
                if self.is_solid(tx, ty):
                    out.append(pygame.Rect(tx * TILE, ty * TILE, TILE, TILE))
        return out

    def laser_col(self, lz, t):
        n = int((t + lz["off"]) / LASER_PERIOD)
        return lz["cols"][n % len(lz["cols"])]

    def beam_bottom(self, col, ty):
        for yy in range(ty + 1, GH):
            if self.is_solid(col, yy):
                return yy * TILE
        return H

    def piston_ext(self, off):
        ph = (self.frames / FPS + off) % PIST_PERIOD
        if ph < PIST_DOWN:
            return 0.0
        if ph < PIST_DOWN + PIST_WARN:
            return 4.0
        if ph < 2.0:
            return PIST_EXT * (ph - 1.8) / 0.2
        if ph < 2.8:
            return float(PIST_EXT)
        return PIST_EXT * (PIST_PERIOD - ph) / 0.2

    def step_play(self):
        keys = self.test_input if self.test_input is not None else pygame.key.get_pressed()
        right = keys[pygame.K_RIGHT] or keys[pygame.K_d] or self.touch["right"]
        left = keys[pygame.K_LEFT] or keys[pygame.K_a] or self.touch["left"]
        dirx = (1 if right else 0) - (1 if left else 0)
        if dirx:
            self.face = dirx
        # horizontal
        self.px = max(0.0, min(float(W - self.pw), self.px + dirx * MOVE))
        r = self.prect()
        for t in self.solid_hits(r):
            if dirx > 0:
                r.right = min(r.right, t.left)
            elif dirx < 0:
                r.left = max(r.left, t.right)
        self.px = float(r.x)
        # vertical
        self.vy = min(self.vy + GRAV, MAXFALL)
        self.py += self.vy
        r = self.prect()
        grounded = False
        hits = self.solid_hits(r)
        if hits:
            if self.vy > 0:
                r.bottom = min(t.top for t in hits)
                grounded = True
            elif self.vy < 0:
                r.top = max(t.bottom for t in hits)
            self.vy = 0.0
            self.py = float(r.y)
        self.coyote = COYOTE if grounded else max(0, self.coyote - 1)
        if grounded and self.feather:
            self.air_extra = 1
        self.jbuf = max(0, self.jbuf - 1)
        if self.jbuf > 0 and (self.coyote > 0 or self.air_extra > 0):
            if self.coyote <= 0:
                self.air_extra -= 1
            self.vy = JUMPV
            self.coyote = self.jbuf = 0
            play(self.snd_jump)
        # crumbling blocks and phase tiles under feet
        if grounded:
            feet = pygame.Rect(r.left, r.bottom, self.pw, 2)
            for (tx, ty), c in self.crumbles.items():
                if c["t"] == -1 and not c["gone"] and \
                        feet.colliderect(pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)):
                    c["t"] = CRUMBLE_DELAY
            for (tx, ty) in self.flickers:
                if feet.colliderect(pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)):
                    self.recent_flicker = 60
        for (tx, ty), c in self.crumbles.items():
            if c["t"] > 0:
                c["t"] -= 1
                if c["t"] == 0:
                    c["gone"] = True
                    self.recent_crumble = 90
                    play(self.snd_crumb)
                    for _ in range(6):
                        self.particles.append(
                            [tx * TILE + TILE / 2, ty * TILE + TILE / 2,
                             random.uniform(-2, 2), random.uniform(-3, 1),
                             random.randint(20, 40), C_CRUMBLE])
        self.recent_crumble = max(0, self.recent_crumble - 1)
        self.recent_flicker = max(0, self.recent_flicker - 1)
        self.invuln = max(0, self.invuln - 1)
        # saws
        for s in self.saws:
            s["x"] += s["dir"] * SAW_SPEED
            if s["x"] <= s["min_x"]:
                s["x"], s["dir"] = s["min_x"], 1
            elif s["x"] >= s["max_x"]:
                s["x"], s["dir"] = s["max_x"], -1
            s["angle"] += 0.25 * s["dir"]
        # sentinels (each with its own pace)
        for v in self.sentries:
            v["y"] += v["dir"] * v["spd"]
            if v["y"] <= v["min_y"]:
                v["y"], v["dir"] = v["min_y"], 1
            elif v["y"] >= v["max_y"]:
                v["y"], v["dir"] = v["max_y"], -1
        # droppers (each with its own weight and reach)
        pcx = self.px + self.pw / 2
        for dr in self.droppers:
            if dr["state"] == "armed":
                dcx = dr["tx"] * TILE + TILE / 2
                if abs(pcx - dcx) < dr["trig"] and self.py > dr["ty"] * TILE:
                    dr["state"] = "falling"
            elif dr["state"] == "falling":
                dr["vy"] = min(dr["vy"] + dr["grav"], MAXFALL)
                dr["y"] += dr["vy"]
                tip = pygame.Rect(dr["tx"] * TILE + 9, int(dr["y"]), 12, 20)
                if self.solid_hits(tip) or dr["y"] > H:
                    dr["state"] = "broken"
                    for _ in range(6):
                        self.particles.append(
                            [dr["tx"] * TILE + 15, dr["y"] + 10,
                             random.uniform(-2, 2), random.uniform(-3, 0),
                             random.randint(15, 30), C_SPIKE])
        # turrets fire; bolts fly left until a wall
        for i, tr in enumerate(self.turrets):
            if self.frames > 0 and (self.frames + i * 60) % BOLT_PERIOD == 0:
                self.bolts.append({"x": tr["tx"] * TILE - 2.0,
                                   "y": 14 * TILE + 13})
        for b in self.bolts[:]:
            b["x"] -= BOLT_SPEED
            btx, bty = int(b["x"]) // TILE, int(b["y"]) // TILE
            if b["x"] < 0 or self.is_solid(btx, bty):
                self.bolts.remove(b)
                for _ in range(3):
                    self.particles.append(
                        [b["x"], b["y"], random.uniform(0, 2),
                         random.uniform(-1.5, 1.5), random.randint(8, 16), C_BOLT])
        # pickups: artifacts and star shards
        pr = self.prect()
        for a in self.artifacts[:]:
            ar = pygame.Rect(a["tx"] * TILE + 4, a["ty"] * TILE + 2,
                             TILE - 8, TILE - 4)
            if pr.colliderect(ar):
                self.artifacts.remove(a)
                play(self.snd_pick)
                if a["kind"] == "shield":
                    self.shield = True
                    self.set_toast("SHIELD CHARM — one death forgiven this attempt")
                else:
                    self.feather = True
                    self.air_extra = 1
                    self.set_toast("FEATHER SIGIL — you can jump once in mid-air")
        for (tx, ty) in list(self.level_shards):
            key = f"{self.li}:{tx}:{ty}"
            if key in self.prog["shards"]:
                continue
            sr = pygame.Rect(tx * TILE + 7, ty * TILE + 7, TILE - 14, TILE - 14)
            if pr.colliderect(sr):
                self.prog["shards"].append(key)
                save_progress(self.prog)
                play(self.snd_shard)
                self.set_toast(f"star shard  —  {self.shard_count()} collected")
                for _ in range(8):
                    a_ = random.uniform(0, math.tau)
                    self.particles.append(
                        [tx * TILE + 15, ty * TILE + 15, math.cos(a_) * 3,
                         math.sin(a_) * 3 - 1, random.randint(15, 30), C_SHARD])
        # deaths
        hazbox = self.prect().inflate(-8, -6)
        if self.py > H + 40:
            if self.recent_crumble > 0:
                self.kill("crumble")
            elif self.recent_flicker > 0:
                self.kill("flicker")
            else:
                self.kill("fall")
            return
        t = self.frames / FPS
        if self.invuln <= 0:
            for (tx, ty) in self.spikes:
                if hazbox.colliderect(pygame.Rect(tx * TILE + 6, ty * TILE + 12,
                                                  TILE - 12, TILE - 12)):
                    self.kill("spike", tile=(tx, ty))
                    return
            for p_ in self.pistons:
                ext = self.piston_ext(p_["off"])
                if ext > 8:
                    base = (p_["ty"] + 1) * TILE
                    if hazbox.colliderect(pygame.Rect(p_["tx"] * TILE + 7,
                                                      int(base - ext),
                                                      TILE - 14, int(ext))):
                        self.kill("piston")
                        return
            for lz in self.lasers:
                phase = (t + lz["off"]) % LASER_PERIOD
                if phase >= LASER_PERIOD - LASER_ON:
                    col = self.laser_col(lz, t)
                    top = lz["ty"] * TILE + 12
                    bottom = self.beam_bottom(col, lz["ty"])
                    beam = pygame.Rect(col * TILE + TILE // 2 - 5, top, 10,
                                       bottom - top)
                    if hazbox.colliderect(beam):
                        self.kill("laser")
                        return
            for i, s in enumerate(self.saws):
                dx = max(hazbox.left, min(s["x"], hazbox.right)) - s["x"]
                dy = max(hazbox.top, min(s["cy"], hazbox.bottom)) - s["cy"]
                if dx * dx + dy * dy < (SAW_R - 2) ** 2:
                    self.kill("saw", idx=i)
                    return
            for i, v in enumerate(self.sentries):
                dx = max(hazbox.left, min(v["cx"], hazbox.right)) - v["cx"]
                dy = max(hazbox.top, min(v["y"], hazbox.bottom)) - v["y"]
                if dx * dx + dy * dy < (SENTRY_R - 1) ** 2:
                    self.kill("sentry", idx=i)
                    return
            for dr in self.droppers:
                if dr["state"] == "falling":
                    if hazbox.colliderect(pygame.Rect(dr["tx"] * TILE + 9,
                                                      int(dr["y"]), 12, 20)):
                        self.kill("dropper")
                        return
            for b in self.bolts:
                if hazbox.colliderect(pygame.Rect(int(b["x"]) - 10,
                                                  int(b["y"]) - 3, 12, 6)):
                    self.kill("bolt")
                    return
        # exit
        if self.prect().colliderect(self.exit_rect):
            play(self.snd_clear)
            g_ = grade_for(self.level_deaths, self.par)
            self.last_grade = g_
            key = str(self.li)
            best = self.prog["best"].get(key)
            if best is None or GRADE_ORDER[g_] > GRADE_ORDER[best]:
                self.prog["best"][key] = g_
            self.unlocked = max(self.unlocked, min(TOTAL_LEVELS, self.li + 2))
            self.menu_sel = self.unlocked
            self.prog["unlocked"] = self.unlocked
            save_progress(self.prog)
            self.state = "win" if self.li == TOTAL_LEVELS - 1 else "clear"
            return
        self.frames += 1

    # ---- update / events
    def update(self):
        if self.state == "play":
            self.step_play()
        if self.toast:
            txt, tl = self.toast
            self.toast = (txt, tl - 1) if tl > 1 else None
        for p in self.particles:
            p[0] += p[2]
            p[1] += p[3]
            p[3] += 0.25
            p[4] -= 1
        self.particles = [p for p in self.particles if p[4] > 0]

    # ---- touch / pointer input (fingers and mouse share one path)
    def advance_tap(self):
        now = pygame.time.get_ticks()
        if now - self._tap_ms < 300:
            return False
        self._tap_ms = now
        return True

    def pick_avatar(self, idx):
        if AVATARS[idx]["need"] <= self.shard_count():
            self.prog["avatar"] = idx
            save_progress(self.prog)

    def pointer_down(self, pos, pid):
        if self.state == "menu":
            if not self.advance_tap():
                return
            if self.m_left_r.collidepoint(pos):
                self.menu_sel = max(1, self.menu_sel - 1)
            elif self.m_right_r.collidepoint(pos):
                self.menu_sel = min(self.unlocked, self.menu_sel + 1)
            else:
                for idx, r in self.m_avatar_rs:
                    if r.collidepoint(pos):
                        self.pick_avatar(idx)
                        return
                self.load_level(self.menu_sel - 1)
                self.state = "play"
        elif self.state == "play":
            if self.hud_log_r.collidepoint(pos):
                if self.advance_tap():
                    self.state = "log"
            elif self.hud_reset_r.collidepoint(pos):
                if self.advance_tap():
                    self.reset_attempt()
            else:
                self.route_pointer(pos, pid)
        elif self.state == "lesson":
            if self.advance_tap():
                self.reset_attempt()
                self.state = "play"
        elif self.state == "clear":
            if self.advance_tap():
                self.load_level(self.li + 1)
                self.state = "play"
        elif self.state == "win":
            if self.advance_tap():
                self.reset_knowledge()
                self.state = "menu"
        elif self.state == "log":
            if self.advance_tap():
                self.state = "play"

    def route_pointer(self, pos, pid):
        hit = None
        for name, r in (("left", BTN_L), ("right", BTN_R), ("jump", BTN_J)):
            if r.collidepoint(pos):
                hit = name
        was_jump = pid in self.touch["jump"]
        for s_ in self.touch.values():
            s_.discard(pid)
        if hit:
            self.show_touch = True
            self.touch[hit].add(pid)
            if hit == "jump" and not was_jump:
                self.jbuf = JBUF

    def pointer_up(self, pid):
        if pid in self.touch["jump"] and len(self.touch["jump"]) == 1 \
                and self.vy < 0:
            self.vy *= 0.45
        for s_ in self.touch.values():
            s_.discard(pid)

    def pointer_move(self, pos, pid):
        if self.state == "play" and any(pid in s_ for s_ in self.touch.values()):
            self.route_pointer(pos, pid)

    def event(self, e):
        if e.type == pygame.QUIT:
            self.running = False
            return
        if e.type == pygame.FINGERDOWN:
            self.show_touch = True
            self.pointer_down((e.x * W, e.y * H), ("f", e.finger_id))
            return
        if e.type == pygame.FINGERUP:
            self.pointer_up(("f", e.finger_id))
            return
        if e.type == pygame.FINGERMOTION:
            self.pointer_move((e.x * W, e.y * H), ("f", e.finger_id))
            return
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.pointer_down(e.pos, "mouse")
            return
        if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            self.pointer_up("mouse")
            return
        if e.type == pygame.MOUSEMOTION:
            if e.buttons and e.buttons[0]:
                self.pointer_move(e.pos, "mouse")
            return
        if e.type != pygame.KEYDOWN and e.type != pygame.KEYUP:
            return
        jump_keys = (pygame.K_SPACE, pygame.K_UP, pygame.K_w)
        if self.state == "play":
            if e.type == pygame.KEYDOWN:
                if e.key in jump_keys:
                    self.jbuf = JBUF
                elif e.key == pygame.K_r:
                    self.reset_attempt()
                elif e.key == pygame.K_TAB:
                    self.state = "log"
            elif e.type == pygame.KEYUP and e.key in jump_keys and self.vy < 0:
                self.vy *= 0.45
        elif e.type == pygame.KEYDOWN:
            if self.state == "menu":
                if e.key in (pygame.K_LEFT, pygame.K_a):
                    self.menu_sel = max(1, self.menu_sel - 1)
                elif e.key in (pygame.K_RIGHT, pygame.K_d):
                    self.menu_sel = min(self.unlocked, self.menu_sel + 1)
                elif e.key in (pygame.K_DOWN, pygame.K_s):
                    self.menu_sel = max(1, self.menu_sel - 10)
                elif e.key in (pygame.K_UP, pygame.K_w):
                    self.menu_sel = min(self.unlocked, self.menu_sel + 10)
                elif e.key == pygame.K_c:
                    nxt = (self.prog["avatar"] + 1) % len(AVATARS)
                    while AVATARS[nxt]["need"] > self.shard_count():
                        nxt = (nxt + 1) % len(AVATARS)
                    self.pick_avatar(nxt)
                elif e.key == pygame.K_SPACE:
                    self.load_level(self.menu_sel - 1)
                    self.state = "play"
            elif self.state == "lesson" and e.key == pygame.K_SPACE:
                self.reset_attempt()
                self.state = "play"
            elif self.state == "clear" and e.key == pygame.K_SPACE:
                self.load_level(self.li + 1)
                self.state = "play"
            elif self.state == "win" and e.key == pygame.K_r:
                self.reset_knowledge()
                self.state = "menu"
            elif self.state == "log" and e.key in (pygame.K_TAB, pygame.K_ESCAPE,
                                                   pygame.K_SPACE):
                self.state = "play"

    # ---- drawing
    def draw(self):
        s = self.screen
        pal = PALETTES[0] if self.state in ("menu", "win") else \
            PALETTES[min(9, self.li // 10)]
        s.fill(pal[0])
        pygame.draw.rect(s, pal[1], (0, H // 2, W, H // 2))
        tick = pygame.time.get_ticks() / 1000
        for x, y, b in self.stars:
            g = int(60 + 50 * b * (0.6 + 0.4 * math.sin(tick * 2 + x)))
            s.fill((g, g, min(255, g + 25)), (x, y, 2, 2))
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "win":
            self.draw_win()
        else:
            self.draw_world()
            if self.state == "play" and self.show_touch:
                self.draw_touch()
            if self.state == "lesson":
                self.draw_lesson()
            elif self.state == "clear":
                self.draw_clear()
            elif self.state == "log":
                self.draw_log()
        for p in self.particles:
            a = max(0, min(255, p[4] * 6))
            sz = 3 if p[4] > 20 else 2
            surf = pygame.Surface((sz, sz))
            surf.fill(p[5])
            surf.set_alpha(a)
            self.screen.blit(surf, (p[0], p[1]))

    def draw_world(self):
        s = self.screen
        k = self.know
        t = self.frames / FPS
        for (tx, ty) in self.solids:
            r = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
            pygame.draw.rect(s, C_TILE, r)
            pygame.draw.rect(s, C_TILE_TOP, (r.x, r.y, TILE, 3))
        for (tx, ty), c in self.crumbles.items():
            if c["gone"]:
                continue
            ox = random.randint(-2, 2) if c["t"] > 0 else 0
            r = pygame.Rect(tx * TILE + ox, ty * TILE, TILE, TILE)
            base = C_CRUMBLE if k["crumble"] else C_TILE
            pygame.draw.rect(s, base, r)
            pygame.draw.rect(s, C_TILE_TOP, (r.x, r.y, TILE, 3))
            crack = C_CRUMBLE_HI if k["crumble"] else (52, 58, 82)
            pygame.draw.line(s, crack, (r.x + 6, r.y + 8), (r.x + 14, r.y + 18), 2)
            pygame.draw.line(s, crack, (r.x + 14, r.y + 18), (r.x + 10, r.y + 26), 2)
            pygame.draw.line(s, crack, (r.x + 20, r.y + 5), (r.x + 24, r.y + 16), 2)
        for (tx, ty), off in self.flickers.items():
            ph = (t + off) % FLICK_PERIOD
            r = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
            if ph < FLICK_SOLID:
                pygame.draw.rect(s, C_FLICK, r)
                pygame.draw.rect(s, (120, 220, 230), (r.x, r.y, TILE, 3))
            elif ph < FLICK_SOLID + FLICK_WARN:
                if (self.frames // 4) % 2:
                    pygame.draw.rect(s, (200, 240, 245), r)
                else:
                    pygame.draw.rect(s, C_FLICK, r)
                pygame.draw.rect(s, (235, 250, 255), r, 2)
            else:
                g = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
                pygame.draw.rect(g, (90, 170, 180, 60), g.get_rect(), 1)
                s.blit(g, r.topleft)
        er = self.exit_rect
        pygame.draw.rect(s, (30, 80, 45), er.inflate(8, 8), border_radius=6)
        pygame.draw.rect(s, C_EXIT, er, border_radius=4)
        pygame.draw.rect(s, (200, 255, 210), er, 2, border_radius=4)
        pygame.draw.circle(s, (30, 80, 45), (er.right - 8, er.centery), 3)
        txt = self.f_small.render("EXIT", True, (10, 40, 20))
        s.blit(txt, (er.centerx - txt.get_width() // 2, er.y + 6))
        # spikes
        for (tx, ty) in self.spikes:
            bx, by = tx * TILE, (ty + 1) * TILE
            if (self.li, tx, ty) in k["spikes"]:
                for i in range(3):
                    x0 = bx + i * 10
                    pygame.draw.polygon(s, C_SPIKE,
                                        [(x0, by), (x0 + 10, by), (x0 + 5, by - 22)])
                    pygame.draw.polygon(s, (255, 150, 160),
                                        [(x0 + 3, by), (x0 + 5, by - 22), (x0 + 5, by)], 1)
            else:
                tw = 0.5 + 0.5 * math.sin(tick_now() * 2.6 + tx * 1.9)
                a = int(45 + 85 * tw)
                g = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
                for gx, gy, r_ in ((7, 22, 2), (16, 25, 3), (24, 20, 2)):
                    pygame.draw.line(g, (240, 244, 255, a), (gx - r_, gy), (gx + r_, gy), 1)
                    pygame.draw.line(g, (240, 244, 255, a), (gx, gy - r_), (gx, gy + r_), 1)
                s.blit(g, (bx, ty * TILE))
        # piston spikes: visible base, blade on a cycle
        for p_ in self.pistons:
            bx, base = p_["tx"] * TILE, (p_["ty"] + 1) * TILE
            ext = self.piston_ext(p_["off"])
            if ext > 0:
                top = base - ext
                for i in range(2):
                    x0 = bx + 5 + i * 11
                    pygame.draw.polygon(s, C_SPIKE,
                                        [(x0, base), (x0 + 9, base),
                                         (x0 + 4, int(top))])
                pygame.draw.line(s, (255, 170, 180), (bx + 9, base - 4),
                                 (bx + 9, int(top) + 3), 1)
            rattling = 0 < ext <= 4
            ox = random.randint(-1, 1) if rattling else 0
            pygame.draw.rect(s, C_PISTON, (bx + 4 + ox, base - 6, TILE - 8, 6))
            pygame.draw.rect(s, (170, 176, 190), (bx + 4 + ox, base - 6, TILE - 8, 2))
        # lasers (generated ones hop between arch columns)
        for lz in self.lasers:
            col = self.laser_col(lz, t)
            ex, ey = col * TILE, lz["ty"] * TILE
            phase = (t + lz["off"]) % LASER_PERIOD
            firing = phase >= LASER_PERIOD - LASER_ON
            warning = (k["laser"] and
                       LASER_PERIOD - LASER_ON - LASER_WARN <= phase < LASER_PERIOD - LASER_ON)
            colr = C_LASER if firing else ((255, 190, 90) if warning else (120, 60, 70))
            pygame.draw.rect(s, (60, 40, 55), (ex + 7, ey, TILE - 14, 14))
            pygame.draw.rect(s, colr, (ex + 10, ey + 3, TILE - 20, 9))
            cx = ex + TILE // 2
            bottom = self.beam_bottom(col, lz["ty"])
            if firing:
                beam = pygame.Surface((14, bottom - ey - 12), pygame.SRCALPHA)
                beam.fill((255, 80, 80, 70))
                s.blit(beam, (cx - 7, ey + 12))
                pygame.draw.line(s, (255, 210, 210), (cx, ey + 12), (cx, bottom), 3)
            elif warning:
                for yy in range(ey + 16, bottom, 14):
                    pygame.draw.line(s, (255, 190, 90), (cx, yy), (cx, yy + 5), 1)
        # saws + revealed paths
        for i, sw in enumerate(self.saws):
            if (self.li, i) in k["saws"]:
                for xx in range(int(sw["min_x"]), int(sw["max_x"]), 16):
                    pygame.draw.circle(s, (200, 120, 130), (xx, int(sw["cy"])), 2)
            cx, cy = int(sw["x"]), int(sw["cy"])
            pygame.draw.circle(s, C_SAW, (cx, cy), SAW_R)
            for j in range(8):
                a = sw["angle"] + j * math.tau / 8
                pygame.draw.line(s, C_SAW, (cx, cy),
                                 (cx + math.cos(a) * (SAW_R + 5),
                                  cy + math.sin(a) * (SAW_R + 5)), 3)
            pygame.draw.circle(s, (90, 95, 110), (cx, cy), 5)
        # sentinels + revealed lanes
        for i, v in enumerate(self.sentries):
            cx, cy = int(v["cx"]), int(v["y"])
            if (self.li, i) in k["sentries"]:
                for yy in range(int(v["min_y"]), int(v["max_y"]), 16):
                    pygame.draw.circle(s, (170, 110, 200), (cx, yy), 2)
            pulse = 2 * math.sin(tick_now() * 5 + i)
            pts = [(cx, cy - SENTRY_R - pulse), (cx + SENTRY_R, cy),
                   (cx, cy + SENTRY_R + pulse), (cx - SENTRY_R, cy)]
            pygame.draw.polygon(s, C_SENTRY, pts)
            pygame.draw.polygon(s, (240, 210, 255), pts, 2)
            pygame.draw.circle(s, (60, 25, 75), (cx, cy), 4)
        # droppers
        for dr in self.droppers:
            if dr["state"] == "broken":
                continue
            dx0 = dr["tx"] * TILE
            y0 = int(dr["y"])
            if dr["state"] == "armed":
                pygame.draw.rect(s, (60, 40, 55), (dx0 + 8, dr["ty"] * TILE, 14, 6))
                if k["dropper"]:
                    gy = dr["ty"] * TILE + 28
                    while gy < 14 * TILE and not self.is_solid(dr["tx"], gy // TILE):
                        pygame.draw.line(s, (160, 70, 85), (dx0 + 15, gy),
                                         (dx0 + 15, gy + 6), 1)
                        gy += 18
            pygame.draw.polygon(s, C_SPIKE,
                                [(dx0 + 7, y0), (dx0 + 23, y0), (dx0 + 15, y0 + 20)])
            pygame.draw.polygon(s, (255, 150, 160),
                                [(dx0 + 7, y0), (dx0 + 23, y0), (dx0 + 15, y0 + 20)], 1)
        # turrets + bolts
        for i, tr in enumerate(self.turrets):
            tx0, ty0 = tr["tx"] * TILE, tr["ty"] * TILE
            pygame.draw.rect(s, (70, 60, 80), (tx0 + 4, ty0 + 12, 24, 16),
                             border_radius=4)
            pygame.draw.rect(s, (120, 105, 135), (tx0 + 4, ty0 + 12, 24, 16), 2,
                             border_radius=4)
            barrel = pygame.Rect(tx0 - 8, 14 * TILE + 9, 16, 8)
            pygame.draw.rect(s, (90, 80, 100), barrel, border_radius=3)
            rem = BOLT_PERIOD - ((self.frames + i * 60) % BOLT_PERIOD)
            if rem <= BOLT_WARN:
                pygame.draw.circle(s, C_BOLT, (tx0 - 8, 14 * TILE + 13), 5)
            if k["bolt"]:
                cx_ = tr["tx"] - 1
                while cx_ > 0 and (cx_, 14) not in self.solids:
                    cx_ -= 1
                for xx in range((cx_ + 1) * TILE, tx0 - 8, 14):
                    pygame.draw.line(s, (180, 160, 95), (xx, 14 * TILE + 13),
                                     (xx + 6, 14 * TILE + 13), 1)
        for b in self.bolts:
            pygame.draw.rect(s, C_BOLT, (int(b["x"]) - 10, int(b["y"]) - 2, 10, 5),
                             border_radius=2)
            pygame.draw.rect(s, (255, 250, 200), (int(b["x"]) - 4, int(b["y"]) - 1, 4, 3))
        # artifacts and shards
        bob = 3 * math.sin(tick_now() * 3)
        for a in self.artifacts:
            ax, ay = a["tx"] * TILE + 15, a["ty"] * TILE + 15 + bob
            if a["kind"] == "shield":
                pts = [(ax, ay - 10), (ax + 9, ay), (ax, ay + 10), (ax - 9, ay)]
                pygame.draw.polygon(s, C_GOLD, pts)
                pygame.draw.polygon(s, (255, 240, 200), pts, 2)
                pygame.draw.circle(s, (120, 90, 30), (int(ax), int(ay)), 3)
            else:
                pts = [(ax - 8, ay + 8), (ax + 9, ay - 9), (ax + 3, ay + 1),
                       (ax + 7, ay + 5), (ax - 4, ay + 6)]
                pygame.draw.polygon(s, (120, 230, 245), pts)
                pygame.draw.polygon(s, (220, 250, 255), pts, 1)
        for (tx, ty) in self.level_shards:
            if f"{self.li}:{tx}:{ty}" in self.prog["shards"]:
                continue
            cx, cy = tx * TILE + 15, ty * TILE + 15 + bob * 0.6
            tw = 0.6 + 0.4 * math.sin(tick_now() * 4 + tx)
            r1, r2 = 7 * tw + 2, 3
            pts = []
            for j in range(8):
                rr = r1 if j % 2 == 0 else r2
                ang = j * math.tau / 8 - math.pi / 2
                pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
            pygame.draw.polygon(s, C_SHARD, pts)
            pygame.draw.polygon(s, (255, 255, 230), pts, 1)
        # death markers (skulls)
        for (mx, my) in k["markers"].get(self.li, []):
            pygame.draw.circle(s, (120, 60, 70), (int(mx), int(my)), 6)
            s.fill((25, 15, 20), (int(mx) - 3, int(my) - 2, 2, 3))
            s.fill((25, 15, 20), (int(mx) + 1, int(my) - 2, 2, 3))
        # player
        if self.state in ("play", "clear", "log"):
            pr = self.prect()
            av = self.avatar
            col = av["col"]
            if self.invuln > 0 and (self.frames // 4) % 2:
                col = (255, 255, 255)
            pygame.draw.rect(s, col, pr, border_radius=5)
            pygame.draw.rect(s, av["edge"], pr, 2, border_radius=5)
            eye_dx = int(self.pw * 0.22) if self.face >= 0 else -1
            ey = pr.y + int(self.ph * 0.26)
            s.fill((15, 30, 40), (pr.x + int(self.pw * 0.18) + eye_dx, ey, 3, 5))
            s.fill((15, 30, 40), (pr.x + int(self.pw * 0.52) + eye_dx, ey, 3, 5))
            if self.shield:
                pygame.draw.circle(s, C_GOLD, pr.center,
                                   max(self.pw, self.ph) // 2 + 7, 1)
            if self.feather and self.air_extra > 0:
                pygame.draw.circle(s, (120, 230, 245),
                                   (pr.centerx, pr.top - 6), 2)
        self.draw_hud()
        if self.toast:
            txt, tl = self.toast
            a = min(255, tl * 6)
            surf = self.f_body.render(txt, True, C_GOLD)
            surf.set_alpha(a)
            s.blit(surf, (W // 2 - surf.get_width() // 2, 40))
        if self.li == 0 and self.know["deaths"] == 0 and self.state == "play":
            tip = self.f_small.render("A / D or arrows to move  ·  SPACE to jump",
                                      True, C_DIM)
            s.blit(tip, (self.start[0] - 40, self.start[1] - 40))

    def draw_hud(self):
        s = self.screen
        lv = self.lvdata
        bar = pygame.Surface((W, 30), pygame.SRCALPHA)
        bar.fill((8, 9, 16, 200))
        s.blit(bar, (0, 0))
        prog = self.f_small.render(f"LEVEL {self.li + 1}/{TOTAL_LEVELS}",
                                   True, C_GOLD)
        s.blit(prog, (12, 8))
        label = lv["name"] + "  —  " + lv["hint"]
        if self.f_small.size(label)[0] > 295:
            label = lv["name"]
        s.blit(self.f_small.render(label, True, C_TEXT),
               (12 + prog.get_width() + 14, 8))
        mid = self.f_small.render(
            f"LESSONS {len(self.know['lessons'])}   ·   "
            f"DEATHS {self.level_deaths} / PAR {self.par}", True, C_GOLD)
        s.blit(mid, (W // 2 - mid.get_width() // 2 + 70, 8))

        def pill(text, right_x, color=C_DIM):
            t = self.f_small.render(text, True, color)
            r = pygame.Rect(0, 0, t.get_width() + 18, 24)
            r.topright = (right_x, 3)
            pygame.draw.rect(s, (36, 40, 62), r, border_radius=12)
            pygame.draw.rect(s, (70, 78, 112), r, 1, border_radius=12)
            s.blit(t, (r.x + 9, r.y + 4))
            return r
        self.hud_reset_r = pill("RESTART (R)", W - 10)
        self.hud_log_r = pill("LESSONS (TAB)", self.hud_reset_r.left - 8)
        pill(f"* {self.shard_count()}", self.hud_log_r.left - 8, C_SHARD)

    def draw_touch(self):
        s = self.screen
        for name, r in (("left", BTN_L), ("right", BTN_R), ("jump", BTN_J)):
            a = 70 if self.touch[name] else 30
            surf = pygame.Surface(r.size, pygame.SRCALPHA)
            pygame.draw.rect(surf, (255, 255, 255, a), surf.get_rect(),
                             border_radius=20)
            pygame.draw.rect(surf, (255, 255, 255, 80), surf.get_rect(), 2,
                             border_radius=20)
            cx, cy = r.w // 2, r.h // 2
            if name == "left":
                pts = [(cx + 12, cy - 18), (cx + 12, cy + 18), (cx - 16, cy)]
            elif name == "right":
                pts = [(cx - 12, cy - 18), (cx - 12, cy + 18), (cx + 16, cy)]
            else:
                pts = [(cx - 18, cy + 12), (cx + 18, cy + 12), (cx, cy - 16)]
            pygame.draw.polygon(surf, (235, 242, 255, 170), pts)
            s.blit(surf, r.topleft)

    def panel(self, w_, h_):
        px, py = (W - w_) // 2, (H - h_) // 2
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        dim.fill((5, 6, 12, 190))
        self.screen.blit(dim, (0, 0))
        r = pygame.Rect(px, py, w_, h_)
        pygame.draw.rect(self.screen, (20, 22, 38), r, border_radius=12)
        pygame.draw.rect(self.screen, C_GOLD, r, 2, border_radius=12)
        return r

    def draw_lesson(self):
        r = self.panel(660, 300)
        s = self.screen
        h = self.f_h2.render(f"DEATH #{self.know['deaths']} — AND A NEW LESSON",
                             True, C_SPIKE)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 24))
        n, _ = self.know["lessons"][-1]
        sub = self.f_small.render(f"LESSON {n} OF YOUR CURRICULUM", True, C_DIM)
        s.blit(sub, (r.centerx - sub.get_width() // 2, r.y + 62))
        y = r.y + 96
        for line in wrap_text(self.lesson_text, self.f_body, r.w - 70):
            t = self.f_body.render(line, True, C_TEXT)
            s.blit(t, (r.centerx - t.get_width() // 2, y))
            y += 28
        if self.lesson_note:
            note = self.f_small.render(self.lesson_note, True, C_EXIT)
            s.blit(note, (r.centerx - note.get_width() // 2, y + 8))
        foot = self.f_small.render("SPACE or tap — apply what you learned",
                                   True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 36))

    def draw_clear(self):
        r = self.panel(560, 250)
        s = self.screen
        h = self.f_h2.render(
            f"LEVEL {self.li + 1} OF {TOTAL_LEVELS} CLEARED", True, C_EXIT)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 26))
        g_ = self.last_grade
        gt = self.f_h2.render(
            f"GRADE  {g_}" + ("  —  FLAWLESS" if g_ == "S" else ""),
            True, GRADE_COLORS[g_])
        s.blit(gt, (r.centerx - gt.get_width() // 2, r.y + 70))
        b = self.f_body.render(
            f"Deaths this level: {self.level_deaths}   ·   Par: {self.par}",
            True, C_TEXT)
        s.blit(b, (r.centerx - b.get_width() // 2, r.y + 116))
        if g_ == "S":
            star = self.f_small.render("* deathless badge earned *", True, C_GOLD)
            s.blit(star, (r.centerx - star.get_width() // 2, r.y + 148))
        tot = self.f_small.render(
            f"Total deaths: {self.know['deaths']}   ·   Lessons: "
            f"{len(self.know['lessons'])}   ·   Shards: {self.shard_count()}",
            True, C_DIM)
        s.blit(tot, (r.centerx - tot.get_width() // 2, r.y + 174))
        foot = self.f_small.render("SPACE or tap — descend further", True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 32))

    def draw_log(self):
        r = self.panel(760, 460)
        s = self.screen
        h = self.f_h2.render("YOUR CURRICULUM", True, C_GOLD)
        s.blit(h, (r.centerx - h.get_width() // 2, r.y + 18))
        lessons = self.know["lessons"]
        y = r.y + 66
        shown = lessons[-9:]
        if not lessons:
            t = self.f_body.render("No lessons yet. The labyrinth awaits your "
                                   "first mistake.", True, C_DIM)
            s.blit(t, (r.centerx - t.get_width() // 2, y + 20))
        if len(lessons) > len(shown):
            t = self.f_small.render(f"… {len(lessons) - len(shown)} earlier "
                                    f"lessons remembered …", True, C_DIM)
            s.blit(t, (r.x + 34, y))
            y += 22
        for n, txt in shown:
            lines = wrap_text(f"{n}. {txt}", self.f_small, r.w - 68)
            for i, line in enumerate(lines[:2]):
                t = self.f_small.render(line + ("…" if i == 1 and len(lines) > 2 else ""),
                                        True, C_TEXT if n == lessons[-1][0] else C_DIM)
                s.blit(t, (r.x + 34, y))
                y += 18
            y += 6
        foot = self.f_small.render("TAB or tap — back to the labyrinth",
                                   True, C_GOLD)
        s.blit(foot, (r.centerx - foot.get_width() // 2, r.bottom - 30))

    def draw_menu(self):
        s = self.screen
        h = self.f_title.render("FAIL FORWARD", True, (90, 220, 235))
        s.blit(h, (W // 2 - h.get_width() // 2, 60))
        sub = self.f_h2.render("every death teaches you something new", True, C_GOLD)
        s.blit(sub, (W // 2 - sub.get_width() // 2, 126))
        lines = [
            "A lone spark descends a labyrinth sinking toward the ember core.",
            "100 levels, a new danger every ten. Each death reveals its killer",
            "and grants a never-repeated lesson. Grades, badges and star shards",
            "are saved forever.   A/D move · SPACE jump · R restart · TAB lessons",
        ]
        y = 180
        for line in lines:
            t = self.f_body.render(line, True, C_TEXT)
            s.blit(t, (W // 2 - t.get_width() // 2, y))
            y += 25
        # avatar picker
        lbl = self.f_small.render(
            f"AVATAR (C to cycle)  ·  star shards: {self.shard_count()}",
            True, C_DIM)
        s.blit(lbl, (W // 2 - lbl.get_width() // 2, 292))
        self.m_avatar_rs = []
        bw, gap = 118, 14
        x0 = W // 2 - (bw * 4 + gap * 3) // 2
        for i, av in enumerate(AVATARS):
            r = pygame.Rect(x0 + i * (bw + gap), 314, bw, 74)
            self.m_avatar_rs.append((i, r))
            sel = i == self.prog["avatar"]
            unlocked = av["need"] <= self.shard_count()
            pygame.draw.rect(s, (36, 40, 62), r, border_radius=10)
            pygame.draw.rect(s, C_GOLD if sel else (70, 78, 112), r,
                             2 if sel else 1, border_radius=10)
            pv = pygame.Rect(0, 0, av["w"], av["h"])
            pv.center = (r.centerx, r.y + 30)
            col = av["col"] if unlocked else (60, 64, 80)
            pygame.draw.rect(s, col, pv, border_radius=4)
            if unlocked:
                s.fill((15, 30, 40), (pv.x + 4, pv.y + 7, 3, 4))
                s.fill((15, 30, 40), (pv.x + av["w"] - 7, pv.y + 7, 3, 4))
            name = self.f_small.render(
                av["name"] if unlocked else f"{av['need']} shards",
                True, C_TEXT if unlocked else C_DIM)
            s.blit(name, (r.centerx - name.get_width() // 2, r.bottom - 20))
        # level selector
        sel = self.f_h2.render(f"LEVEL {self.menu_sel} / {TOTAL_LEVELS}",
                               True, C_TEXT)
        s.blit(sel, (W // 2 - sel.get_width() // 2, 404))
        for r, left in ((self.m_left_r, True), (self.m_right_r, False)):
            can = self.menu_sel > 1 if left else self.menu_sel < self.unlocked
            col = (235, 242, 255) if can else (80, 86, 110)
            pygame.draw.rect(s, (36, 40, 62), r, border_radius=12)
            pygame.draw.rect(s, (70, 78, 112), r, 1, border_radius=12)
            cx, cy = r.centerx, r.centery
            if left:
                pts = [(cx + 8, cy - 12), (cx + 8, cy + 12), (cx - 10, cy)]
            else:
                pts = [(cx - 8, cy - 12), (cx - 8, cy + 12), (cx + 10, cy)]
            pygame.draw.polygon(s, col, pts)
        best = self.prog["best"].get(str(self.menu_sel - 1))
        if best == "S":
            btxt, bcol = "best grade: S  ·  * deathless *", C_GOLD
        elif best:
            btxt, bcol = f"best grade: {best}", GRADE_COLORS[best]
        else:
            btxt, bcol = "not yet cleared", C_DIM
        bt = self.f_small.render(btxt, True, bcol)
        s.blit(bt, (W // 2 - bt.get_width() // 2, 446))
        badges = sum(1 for v in self.prog["best"].values() if v == "S")
        info = self.f_small.render(
            f"unlocked: {self.unlocked}/{TOTAL_LEVELS}  ·  badges: {badges}  ·  "
            f"left/right: level  ·  up/down: jump 10",
            True, C_DIM)
        s.blit(info, (W // 2 - info.get_width() // 2, 468))
        if (pygame.time.get_ticks() // 400) % 2:
            go = self.f_h2.render("SPACE OR TAP TO FAIL", True, C_SPIKE)
            s.blit(go, (W // 2 - go.get_width() // 2, 494))

    def draw_win(self):
        s = self.screen
        h = self.f_title.render("LABYRINTH SOLVED", True, C_EXIT)
        s.blit(h, (W // 2 - h.get_width() // 2, 110))
        k = self.know
        badges = sum(1 for v in self.prog["best"].values() if v == "S")
        lines = [
            f"All {TOTAL_LEVELS} levels. You died {k['deaths']} times.",
            f"You learned {len(k['lessons'])} lessons.",
            f"Deathless badges: {badges} / {TOTAL_LEVELS}   ·   "
            f"Star shards: {self.shard_count()}.",
            "",
            "That was never failure. That was the curriculum.",
        ]
        y = 210
        for line in lines:
            t = self.f_h2.render(line, True, C_TEXT) if line else None
            if t:
                s.blit(t, (W // 2 - t.get_width() // 2, y))
            y += 42
        foot = self.f_body.render("R or tap — run it back (the labyrinth forgets, too)",
                                  True, C_GOLD)
        s.blit(foot, (W // 2 - foot.get_width() // 2, 440))


def tick_now():
    return pygame.time.get_ticks() / 1000


# ---------------------------------------------------------------- main
async def main():
    validate_levels()
    os.environ.setdefault("SDL_TOUCH_MOUSE_EVENTS", "0")
    os.environ.setdefault("SDL_MOUSE_TOUCH_EVENTS", "0")
    try:
        pygame.mixer.pre_init(22050, -16, 1, 512)
    except Exception:
        pass
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Fail Forward")
    clock = pygame.time.Clock()
    g = Game(screen)
    while g.running:
        for e in pygame.event.get():
            g.event(e)
        g.update()
        g.draw()
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
    pygame.quit()


def selftest():
    """Headless smoke test for every system."""
    validate_levels()
    assert gen_level(42)["map"] == gen_level(42)["map"], "generator not deterministic"
    assert grade_for(0, 3) == "S" and grade_for(3, 3) == "A"
    assert grade_for(6, 3) == "B" and grade_for(7, 3) == "C"
    for base, ch in ((21, "D"), (31, "V"), (41, "T"), (51, "F")):
        for lvl in range(base, base + 10):
            assert ch in "".join(level_data(lvl - 1)["map"]), \
                f"level {lvl}: missing decade hazard {ch}"
    for lvl in range(61, 71):
        assert "".join(level_data(lvl - 1)["map"]).count("L") >= 2, lvl
    for lvl in range(71, 81):
        assert "".join(level_data(lvl - 1)["map"]).count("M") >= 2, lvl
    for lvl in range(81, 91):
        assert "".join(level_data(lvl - 1)["map"]).count("D") >= 3, lvl
    # spike sky bricks are random now: some runs covered, some not
    covered = uncovered = 0
    for ix in range(10, TOTAL_LEVELS):
        m = level_data(ix)["map"]
        c = 0
        while c < GW:
            if m[14][c] == "^":
                r0 = c
                while c < GW and m[14][c] == "^":
                    c += 1
                if any(m[12][x] in "#C" for x in range(r0, c)):
                    covered += 1
                else:
                    uncovered += 1
            else:
                c += 1
    assert covered > 0 and uncovered > 0, "spike bricks should be a coin flip"
    # pistons, artifacts and shards exist
    allmaps = ["".join(level_data(ix)["map"]) for ix in range(TOTAL_LEVELS)]
    assert any("P" in m for m in allmaps[15:]), "no pistons"
    assert any("A" in m for m in allmaps) and any("J" in m for m in allmaps), \
        "no artifacts"
    assert sum(m.count("o") for m in allmaps) > 100, "too few shards"
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    g = Game(screen)

    class Held(dict):
        def __getitem__(self, k):
            return dict.get(self, k, 0)

    # every level parses, loads and survives simulation
    spds = set()
    hop = False
    for i in range(TOTAL_LEVELS):
        g.load_level(i)
        g.state = "play"
        g.test_input = Held()
        spds |= {round(v["spd"], 3) for v in g.sentries}
        hop = hop or any(len(lz["cols"]) > 1 for lz in g.lasers)
        for _ in range(10):
            g.update()
        g.state = "play"
    assert len(spds) > 5, "sentinel speeds do not vary"
    assert hop, "no hopping lasers found"
    # deeper soak across all hazard decades, with rendering
    for i in (0, 1, 2, 3, 4, 10, 17, 24, 34, 44, 54, 64, 74, 84, 94, 99):
        g.load_level(i)
        g.state = "play"
        for _ in range(150):
            g.update()
            g.draw()
        assert g.state in ("play", "lesson"), f"level {i}: state {g.state}"
        g.state = "play"
    # shield forgives one contact death; feather grants an air jump
    g.reset_knowledge()
    g.load_level(0)
    g.state = "play"
    g.test_input = Held()
    g.shield = True
    deaths0 = g.know["deaths"]
    g.kill("spike", tile=(20, 14))
    assert g.state == "play" and not g.shield and g.know["deaths"] == deaths0, \
        "shield did not absorb the death"
    g.invuln = 0
    g.feather = True
    g.air_extra = 1
    g.coyote = 0
    g.jbuf = JBUF
    g.update()
    assert g.vy < 0, "feather air jump did not fire"
    # touch controls move the player
    g.load_level(0)
    g.state = "play"
    x0 = g.px
    g.pointer_down(BTN_R.center, ("f", 1))
    for _ in range(30):
        g.update()
    assert g.px > x0 + 50, "touch right did not move player"
    g.pointer_up(("f", 1))
    # walking right on level 1 must eventually die and learn something
    g.reset_knowledge()
    g.load_level(0)
    g.state = "play"
    g.test_input = Held({pygame.K_RIGHT: 1})
    for _ in range(900):
        if g.state == "lesson":
            break
        g.update()
    assert g.state == "lesson", "expected a teaching death on level 1"
    assert len(g.know["lessons"]) == 1
    # every death yields a unique lesson, even after hundreds of deaths
    texts = [g.new_lesson(random.choice(list(CAUSE_LESSONS))) for _ in range(300)]
    assert len(set(texts)) == len(texts), "lessons repeated"
    pygame.quit()
    print(f"selftest OK — {TOTAL_LEVELS} levels valid; random spike bricks, "
          "hopping lasers, varied speeds, pistons, artifacts, shards and "
          "avatars all verified; every death teaches a unique lesson")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        selftest()
    else:
        asyncio.run(main())
